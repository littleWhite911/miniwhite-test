// https://umijs.org/config/
import { defineConfig } from 'umi';

export default defineConfig({
  define: {
    LARGE_ORDER_SERVER: 'https://largeorder.harmay.com',
    CI_BUILD_VERSION: process.env.CI_BUILD_VERSION,
    CI_PIPELINE_ID: process.env.CI_PIPELINE_ID,
  },
});
