export default [
  {
    path: '/user',
    layout: false,
    routes: [
      { path: '/user', routes: [{ name: '登录', path: '/user/login', component: './user/Login', hideInTab: true, }] },
      { component: './404' },
    ],
  },
  { path: '/welcome', name: '欢迎', icon: 'smile', component: './Welcome' },
  {
    path: '/order',
    name: '订单中心',
    // code: "product",
    // access: "normalRouteFilter",
    routes: [
      {
        path: 'retailOrderList',
        name: '零售订单',
        component: './order/retailOrderList',
      },
      {
        path: 'retailOrderDetail',
        name: '零售订单详情',
        component: './order/retailOrderDetail',
        hideInMenu: true,
      },
      { component: './404' },
    ],
  },
  { path: '/', redirect: '/welcome' },
  { component: './404' },
];
