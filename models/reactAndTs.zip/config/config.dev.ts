// https://umijs.org/config/
import { defineConfig } from 'umi';

export default defineConfig({
  plugins: [
    // https://github.com/zthxxx/react-dev-inspector
    'react-dev-inspector/plugins/umi/react-inspector',
  ],
  // https://github.com/zthxxx/react-dev-inspector#inspector-loader-props
  inspectorConfig: {
    exclude: [],
    babelPlugins: [],
    babelOptions: {},
  },
  define: {
    LARGE_ORDER_SERVER: 'https://test-largeorder.harmay.com',
    BFF_SERVER: 'https://dev-digital-bff-tob.harmay.com',
    CI_BUILD_VERSION: process.env.CI_BUILD_VERSION,
    CI_PIPELINE_ID: process.env.CI_PIPELINE_ID,
  },
});
