import RightContent from '../RightContent';
import TagsView from './tagsView';
import styles from './index.less';

const TagView = ({
  routes, collapsed, siderWidth,
}: {
  routes: any[];
  collapsed: boolean;
  siderWidth: number;
}) => (
  <div className={styles.tag_view}>
    <RightContent />
    <div className={styles.tabs} style={{ width: `calc(100% - ${collapsed ? '49' : siderWidth}px)` }}>
      <TagsView routes={routes} />
    </div>
  </div>
);

export default TagView;
