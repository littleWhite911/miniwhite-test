
/**
 * 获取新增/编辑标题, 如果有参数则为编辑
 * @param title 标题
 * @param search 参数
 * @returns string
 */
export const getEditTitle = (title: string, search: string) => {
  if (title && search) {
    title = title.replace(/新增|新建|创建/, '编辑');
  }
  return title;
};