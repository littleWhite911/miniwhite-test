import TagView from '@/components/TagView';

const Demo = () => (
  <TagView routes={[{ path: '/welcome' }]} />
);
export default Demo;
