# DetailPageHeader 

## 详情页页头 v0.1

<code src="./demo/index.tsx"></code>

<API></API>