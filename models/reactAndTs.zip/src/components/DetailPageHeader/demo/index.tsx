import DetailPageHeader from '@/components/DetailPageHeader';

const Demo = () => (
  <DetailPageHeader headerName="详情页名字" />
);

export default Demo;
