import { DownOutlined, UpOutlined } from '@ant-design/icons';
import { BaseQueryFilterProps } from '@ant-design/pro-form';
import { Button } from 'antd';

export const tableColConfig = {
  xs: 24,
  sm: 12,
  md: 10,
  lg: 8,
  xl: 6,
  xxl: 4,
};

export const tableSearchRender = (
  { searchText, resetText }: Omit<BaseQueryFilterProps, 'submitter' | 'isForm'>,
  { form }: Omit<BaseQueryFilterProps, 'searchConfig'>,
) => [
  <Button
    key="reset"
    onClick={() => {
      form?.resetFields();
    }}
  >
    {resetText}
  </Button>,
  <Button
    key="primary"
    type="primary"
    onClick={() => {
      form?.submit();
    }}
  >
    {searchText}
  </Button>,
];

export const tableCollapseRender = (collapsed: boolean) => {
  if (collapsed) {
    return <DownOutlined />;
  }
  return <UpOutlined />;
};

export const tablePagination = {
  showQuickJumper: true,
};
