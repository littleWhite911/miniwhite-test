/** 商品分类 */
export const ClassifyEnum = {
  1: '正装',
  2: '旅行装',
  3: '可售tester',
  4: '不可售tester',
  5: '促销品',
  6: '赠品',
};

/** 商品等级 */
export const GradeEnum = {
  1: 'A类',
  2: 'B类',
  3: 'C类',
  4: 'D类',
  6: 'A+类',
  7: 'B+类',
  8: '新品',
  9: '不参与',
};

/** 商品状态 */
export const GoodsStatusEnum = {
  1: '正常',
  2: '滞销',
  3: '淘汰',
  4: '停用',
  5: '下线',
  6: '下架',
};

/** 是否bom品 */
export const BomEnum = {
  0: '没有',
  1: '有',
};

/** 是否配赠 */
export const GiftEnum = {
  0: '没有',
  1: '有',
};

/** 销售渠道 */
export const SaleChannelEnum = {
  1: '线下渠道',
  2: '线上跨境渠道',
  3: '线上非跨境渠道',
  4: 'APP特供',
};

/** 容量单位 */
export const VolumeUnitEnum = {
  1: 'ml',
  2: 'l',
  3: 'g',
  4: 'kg',
  5: 'oz',
  6: 'gal',
  7: 'mm',
};

/** 件单位 */
export const ItemUnitEnum = {
  1: '件',
  2: '盒',
  3: '个',
  4: '支',
  5: '瓶',
  6: '桶',
  7: '条',
  8: '打',
  9: '罐',
  10: '卷',
  11: '枚',
  12: '袋',
};

/** 备案商品类型 */
export const RecordTypeEnum = {
  1: '进口特殊',
  2: '进口非特殊',
  3: '国产特殊',
  4: '国产非特殊',
};
