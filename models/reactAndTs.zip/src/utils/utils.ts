/**
 * 文件流导出表格
 * @param res 文件流
 * @param name 表格名称
 */
 export const ExportExcel = (res: Blob, name: string) => {
  const url = window.URL.createObjectURL(new Blob([res], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
  // 创建A标签
  const link = document.createElement('a');
  link.style.display = 'none';
  link.href = url;
  // 触发点击方法
  link.setAttribute('download', name || '表格');
  document.body.appendChild(link);
  link.click();
};