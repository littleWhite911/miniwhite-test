/**
 * 钉钉扫码登录方法，需要获取钉钉登录二维码时调用
 */
/* eslint-disable no-return-assign */
import { useRef, useCallback } from 'react';
import moment from 'moment';

import { debounce } from 'lodash';

export const ddLogin = () => {
  window.DTFrameLogin(
    {
      id: 'self_defined_element',
      width: 300,
      height: 300,
    },
    {
      redirect_uri: encodeURIComponent(window.location.origin),
      client_id: 'dingfu6q1zt7tvmq7wsa',
      scope: 'openid',
      response_type: 'code',
      prompt: 'consent',
    },
    (loginResult) => {
      const { redirectUrl, authCode } = loginResult;
      // 这里可以直接进行重定向
      console.log(authCode);
      window.location.href = redirectUrl;
      // 也可以在不跳转页面的情况下，使用code进行授权
    },
    (errorMsg) => {
      console.log(errorMsg);
      // 这里一般需要展示登录失败的具体原因
    },
  );
};

interface enumType {
  value: string | number;
  label: string | number;
}
/**
 * 枚举值映射
 * @param val 枚举的值
 * @param enumList 枚举列表
 * @returns 枚举的label
 */
export const mapEnum = (val: any, enumList: Array<enumType>) => {
  let str = null;
  enumList.forEach((v: enumType) => {
    if (v.value === val) {
      str = v.label;
    }
  });
  return str;
};

/**
 * url get参数进行 encodeURIComponent
 * @param passUrl 把url 参数进行encodeURIComponent
 * @returns Sting 返回一个encodeURIComponent的url
 */
export const splitUrlFormatEncode = (passUrl: string): string => {
  // if (!url) return '';
  // // 问号前面的地址
  // let preurl = url.split('?')[0];
  // // get参数
  // const urlLater = url.split('?')[1]?.split('&') || [];
  // for (let i = 0; i < urlLater.length; i++) {
  //   if (urlLater[i].split('=').length > 1) {
  //     preurl += `${i === 0 ? '?' : '&'}${urlLater[i].split('=')[0]}=${encodeURIComponent(urlLater[i].split('=')[1])}`;
  //   } else {
  //     preurl += `${i === 0 ? '?' : '&'}${urlLater[i].split('=')[0]}`;
  //   }
  // }
  // return preurl;
  try {
    const judgeUrl = new URL(passUrl);
    let newFullUrl = `${judgeUrl.origin !== 'null' ? judgeUrl.origin : judgeUrl.protocol}${
      judgeUrl.pathname
    }`;
    const params = new URL(passUrl).searchParams;
    params.forEach((val, name) => {
      const url = new URL(newFullUrl);
      url.searchParams.append(name, val);
      newFullUrl = url.href;
    });
    return newFullUrl;
  } catch (error) {
    return passUrl;
  }
};

/**
 *
 * @param tel 手机号脱敏
 * @returns 返回中间四位数字脱敏
 */
export const getFormatTel = (tel: string): string => {
  if (tel) {
    const reg = /^(\d{3})\d{4}(\d{4})$/;
    return tel.replace(reg, '$1****$2');
  }
  return '';
};

/**
 * 通过出生日期获取周岁年龄
 * @param strBirthday：指的是出生日期，格式为"1990-01-01"
 * @returns 返回周岁
 */
export const getAge = (strBirthday: any = '1990-01-01'): any => {
  let returnAge: any;
  const strBirthdayArr = strBirthday.split('-');
  const birthYear = strBirthdayArr[0];
  const birthMonth = strBirthdayArr[1];
  const birthDay = strBirthdayArr[2];
  const d = new Date();
  const nowYear = d.getFullYear();
  const nowMonth = d.getMonth() + 1;
  const nowDay = d.getDate();
  if (nowYear === birthYear) {
    returnAge = 0; // 同年 则为0周岁
  } else {
    const ageDiff = nowYear - birthYear; // 年之差
    if (ageDiff > 0) {
      if (nowMonth === birthMonth) {
        const dayDiff = nowDay - birthDay; // 日之差
        if (dayDiff < 0) {
          returnAge = ageDiff - 1;
        } else {
          returnAge = ageDiff;
        }
      } else {
        const monthDiff = nowMonth - birthMonth; // 月之差
        if (monthDiff < 0) {
          returnAge = ageDiff - 1;
        } else {
          returnAge = ageDiff;
        }
      }
    } else {
      returnAge = -1; // 返回-1 表示出生日期输入错误 晚于今天
    }
  }
  return returnAge; // 返回周岁年龄
};

/**
 * 根据身份证号码获取出生日期 -- 男女 -- 时间戳
 * @param idCard:身份证号
 * @returns 返回object {birthday: '1990-01-01', sexStr: '男', timestamp: 631123200000}
 */
export const getBirth = (idCard: string): object => {
  let birthday: any;
  let newDataStr;
  if (idCard != null && idCard !== '') {
    if (idCard.length === 15) {
      birthday = `19${idCard.slice(6, 12)}`;
    } else if (idCard.length === 18) {
      birthday = idCard.slice(6, 14);
    }

    birthday = birthday.replace(/(.{4})(.{2})/, '$1-$2-');
    newDataStr = birthday.replace(/-/g, '/');
    // 通过正则表达式来指定输出格式为:1990-01-01
  }
  const timestamp = new Date(newDataStr).getTime();

  let sexStr = '';
  if (parseInt(idCard.slice(-2, -1), 10) % 2 === 1) {
    sexStr = '男';
  } else {
    sexStr = '女';
  }
  return {
    birthday,
    sexStr,
    timestamp,
  };
};
/**
 * 千分位分割
 * @param price 数字、字符串
 * @returns 返回千分位分割的字符串
 */
export const toThousand = (price: number | string | undefined) => {
  if (!price && price !== 0) return '';
  return String(price).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};
/**
 * 文件流导出表格
 * @param res 文件流
 * @param name 表格名称
 */
export const ExportExcel = (res: Blob, name: string) => {
  const url = window.URL.createObjectURL(
    new Blob([res], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
  );
  // 创建A标签
  const link = document.createElement('a');
  link.style.display = 'none';
  link.href = url;
  // 触发点击方法
  link.setAttribute('download', name || '表格');
  document.body.appendChild(link);
  link.click();
};

/**
 * 生成guid
 * @returns string guid
 */
export const guid = () => {
  function S4() {
    // eslint-disable-next-line no-bitwise
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
  }
  return `${S4() + S4()}-${S4()}-${S4()}-${S4()}-${S4()}${S4()}${S4()}`;
};

/**
 * 姓名格式化
 * @param str，字符串
 * @returns 返回 姓**
 */
export const formatNameBehind = (str: string = '') => {
  if (str) {
    return str.substr(0, 1) + new Array(str.length).join('*');
  }
  return '';
};

/**
 * 禁用之前的时间
 * @param 时间
 */

export const disabledBeforeTime = (current: any) => {
  const beforeNow = current && current <= moment().startOf('day');
  return beforeNow;
};

/**
 * 防重复点击hook
 * @param fn 异步点击事件
 */
export function useLockFn<T extends any[], K>(
  fn: (...args: T) => Promise<K>,
): (...args: T) => Promise<K | undefined> {
  const lockRef = useRef(false);

  return useCallback(
    async (...args: T) => {
      if (lockRef.current) return;

      try {
        lockRef.current = true;
        const result = await fn(...args);
        return result;
      } finally {
        lockRef.current = false;
      }
    },
    [fn],
  );
}

/**
 * 运营位赋值活动名称和活动ID
 * 1. 如手动填写活动名称，则使用填写campaignName，无campaignId
 * 2. 如未填写活动名称，并且跳转url选择专题活动页，则使用专题活动名称作为campaignName,专题活动id作为campaignId
 * @param url url
 * @returns boolean
 */
export const setCampaignNameAndId = (targetInfo: any, inputCampaignName: string = '') => {
  const { path, params } = targetInfo;
  let id = '';
  let name = '';
  if (path === '/campaigns') {
    params.forEach((v: any) => {
      if (v.paramKey === 'campaignId') {
        id = v.paramValue;
        name = v.paramLabel;
      }
    });
    return {
      campaignName: inputCampaignName || name,
      campaignId: id,
    };
  }
  return {
    campaignId: undefined,
    campaignName: inputCampaignName,
  };
};

export const useDebounce = <T extends Function>(fn: T, wait = 1000) => {
  const func = useRef(fn);
  func.current = fn;
  const debounceWrapper = useRef(debounce((args: any) => func.current?.(args), wait));
  return debounceWrapper.current as unknown as T;
};
