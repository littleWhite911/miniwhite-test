/**
 * 验证是否是非零的正整数
 * @param rules
 * @param value
 * @param callback
 */
 export const validateGreaterhanZero = (rules: any, value: string | number) => {
  const regexp = /^[1-9]\d*$/;
  if (!regexp.test(value as string)) {
    return Promise.reject(new Error('请输入大于0的整数'));
  }

  return Promise.resolve();
};