import axios from 'axios';
import MyHttp from './typings';
import { requestInterceptors, responseInterceptors, responseErrorHandler } from './interceptors';

const request = axios.create({
  baseURL: API_SERVER,
  loading: false,
  silence: false,
} as MyHttp.RequestConfig);

request.interceptors.request.use(requestInterceptors);

request.interceptors.response.use(responseInterceptors, responseErrorHandler);

export const mdmPrefix = '';

export default request as MyHttp.RequestInstance;
