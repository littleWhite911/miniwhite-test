// import errorHandler  from "@/utils/errorHandle";
import { message } from 'antd';
import { RequestConfig } from 'umi';
import { RequestOptionsInit, ResponseError } from 'umi-request';

const requestInterceptor = (_: string, options: RequestOptionsInit) => ({
  options: {
    ...options,
    headers: {
      ...options.headers,
      // token: 'a14ee61e8e2144999e3deb53e070b68a',
    },
  },
});

const responseInterceptor = async (response: Response) => {
  const { code, data, msg } = await response.clone().json();
  if (response.status === 200) {
    if (code === 0) {
      return data;
    }
    message.error({
      content: msg,
    });
  }
  return response;
};

const errorHandler = (error: ResponseError) => {
  const { response } = error;
  let msg = '';
  if (response) {
    switch (response && response.status) {
      // 非法的token、或者Token 过期、后端强制token失效
      case 401:
        //  无效令牌
        msg = '登录失效，请重新登录';
        break;
      case 404:
        msg = '服务端接口不存在';
        break;
      case 500:
        msg = '服务器出错';
        break;
      default:
        msg = '服务器出错';
        break;
    }
  } else {
    msg = '系统繁忙';
  }
  if (msg) {
    message.error({
      content: msg,
    });
  }
};

// 配置request
export const request: RequestConfig = {
  prefix: BFF_SERVER, // 监测开发环境
  errorHandler,
  requestInterceptors: [requestInterceptor],
  responseInterceptors: [responseInterceptor],
  middlewares: [],
};
