import { request } from 'umi';

export async function getTestList(data?: API.reqList) {
  return request<API.list>('/bff/after-sale/list', {
    method: 'POST',
    data,
  });
}
