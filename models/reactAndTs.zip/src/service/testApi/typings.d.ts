declare namespace API {
  type reqList = {
    a: string;
  };

  type list = {
    id?: number;
  };
}
