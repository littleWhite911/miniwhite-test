declare namespace RetailOrder {
  import { ResPagination } from '@/types';

  interface reqRetailOrderList {
    /** 业务类型 1, 化妆品;2, 柠檬茶;3, 马里昂咖啡; */
    businessType?: number;
    /** erp 对应门店code */
    erpStoreCode?: string;
    /** erp对应的门店仓库编号 */
    erpWarehouseNo?: string;
    /** 平台ID 0:話梅订单; 1:introlemons; 2:马里昂巴; 3:自研pos; 4:闪购(正装); */
    platformId?: string;
    /** 推送oms 状态: -2:数据验证失败 -1:不需要推送 0：推送失败 1:推送成功 */
    pushStatus?: number;
    /** 来源渠道 1:flipos;2:美团;3:饿了么;4:自研Pos */
    sourceChannel?: number;
    /** 源单号 */
    srcOrderNo?: string;
    /** 三方系统实收 */
    thirdPartyPaidPrice?: number;
    /** 第三方单号(主要应用场景 柠檬茶 在flipos 开有 美团饿了么 平台对接，这里三方单号指 饿了嘛，美团 单号) */
    thirdPartyPlatformBill?: number;
    /** 下单时间 开始时间 */
    tradeTimeBegin?: string;
    /** 下单时间 结束时间 */
    tradeTimeEnd?: string;
    /** 第几页 */
    pageNo?: number;
    /** 每页几条 */
    pageSize?: number;
  }

  interface resRetailOrderItem {
    /** 业务类型  1, 化妆品;2, 柠檬茶;3, 马里昂咖啡; */
    businessType?: number;
    /** 订单备注 */
    buyerMessage?: string;
    /** 创建时间 */
    created?: string;
    /** erp对应的门店仓库编号 */
    erpWarehouseNo?: string;
    /** 失败返回信息 */
    errMess?: string;
    /** flipos对应的门店名称 */
    fliposStoreName?: string;
    /** 最后修改时间 */
    modified?: string;
    /** 总金额 */
    originalAmount?: number;
    /** 平台ID 0:話梅订单; 1:introlemons; 2:马里昂巴; 3:自研pos; 4:闪购(正装); */
    platformId: string;
    /** 推送oms 状态: -2:数据验证失败 -1:不需要推送 0：推送失败 1:推送成功 */
    pushStatus?: number;
    /** 服务类型 */
    serviceType?: string;
    /** erp 门店号 */
    shopNo?: string;
    /** 来源渠道 1:flipos;2:美团;3:饿了么;4:自研Pos */
    sourceChannel?: number;
    /** 源订单Id */
    srcOrderId: string;
    /** 源单号 */
    srcOrderNo: string;
    /** 三方系统实收 */
    thirdPartyPaidPrice?: number;
    /** 第三方单号(主要应用场景 柠檬茶 在flipos 开有 美团饿了么 平台对接，这里三方单号指 饿了嘛，美团 单号) */
    thirdPartyPlatformBill?: number;
    /** 订单状态
    5已取消 10待付款 12待尾款 13待选仓 15等未付;
    16延时审核 19预订单前处理 20前处理(赠品，合并，拆分)21委外前处理
    22抢单前处理 25预订单 27待抢单 30待客审 35待财审
    40待递交仓库 45递交仓库中 50已递交仓库 53未确认
    55已确认（已审核） 95已发货 105部分打款
    110已完成 113异常发货 */
    tradeStatus?: number;
    /** 下单时间 */
    tradeTime?: string;
    /** 订单类型 1:网店销售 2线下零售 3售后换货 4批发业务 5保修换新 6保修完成 7订单补发; */
    tradeType?: number;
  }

  interface reqRetailOrderDetail {
    /** 平台ID 0:話梅订单; 1:introlemons; 2:马里昂巴; 3:自研pos; 4:闪购(正装) */
    platformId: string;
    /** 源订单Id */
    srcOrderId: string;
    /** 源订单号 */
    srcOrderNo: string;
  }

  interface discountsItem {
    /** 优惠分类 */
    category?: string;
    /** 优惠金额 */
    couponAmount?: number;
    /** 优惠名称 */
    couponName?: string;
    /** 优惠类别 0：普通优惠 1：vip优惠 */
    couponType?: string;
    /** 商家编码 */
    sku?: string;
    /** 优惠主体 */
    subject?: string;
  }

  interface itemsItem {
    /** 组合商品编码 */
    assemblyCode?: string;
    /** 是否是组合商品 */
    assemblyFlag?: string;
    /** 优惠金额 */
    discountAmount?: number;
    /** 是否是赠品 */
    giftFlag?: string;
    /** 数量 */
    num?: number;
    /** 子订单号 */
    oid?: string;
    /** 原始单价 */
    originalPrice?: number;
    /** 实收单价 */
    payPrice?: number;
    /** 服务类型 */
    serviceType?: string;
    /** 商家编码 */
    sku?: string;
    /** 规格名称 */
    skuName?: string;
    /** 商品名称 */
    spuName?: string;
    /** 实付金额 */
    totalPrice?: number;
  }

  interface paysItem {
    /** 支付金额 */
    amount?: number;
    /** 支付明细id */
    flow?: string;
    /** 支付编码 */
    payChannel?: string;
    /** 订单号 */
    payNo?: string;
    /** 支付方式 */
    payType?: string;
  }

  interface priceItem {
    /** 抹零 */
    adjustment?: number;
    /** 平台服务费(外 卖) */
    commission?: number;
    /** 配送费(外卖,商城) */
    deliveryFee?: number;
    /** 优惠金额 */
    discountAmount?: number;
    /** 赠送金额 */
    giftAmount?: number;
    /** 总金额 */
    originalPrice?: number;
    /** 实付金额 */
    payPrice?: number;
    /** 应收金额 */
    receivable?: number;
  }

  interface receiverItem {
    /** 会员号 */
    mrVipNumber?: string;
    /** 收货人地址 */
    receiverAddress?: string;
    /** 收货人手机号 */
    receiverMobile?: string;
    /** 收货人名称 */
    receiverName?: string;
    /** 收货人性别 */
    receiverSex?: string;
  }

  interface resRetailOrderDetail {
    /** 创建时间 */
    accessTime?: string;
    /** 业务类型 1, 化妆品;2, 柠檬茶;3, 马里昂咖啡; */
    businessType?: string;
    /** 快递公司 */
    courierCompany?: string;
    /** 快递单号 */
    courierNumber?: string;
    /** 优惠信息 */
    discounts?: discountsItem[];
    /** erp对应的门店仓库编号 */
    erpWarehouseNo?: string;
    /** flipos对应的门店名称 */
    fliposStoreName?: string;
    /** 收银员id */
    handlerId?: number;
    /** 商品明细 */
    items?: itemsItem[];
    /** 支付时间 */
    payTime?: string;
    /** 支付方式 */
    payType?: string;
    /** 支付信息 */
    pays?: paysItem[];
    /** 平台名称 */
    platformName?: string;
    /** flipos金额信息 */
    price?: priceItem;
    /** flipos收货人信息 */
    receiver?: receiverItem[];
    /** 买家留言 */
    remark?: string;
    /** 服务类型 */
    serviceType?: string;
    /** 来源渠道 1:flipos;2:美团;3:饿了么;4:自研Pos */
    sourceChannel?: number;
    /** 源单号 */
    srcOrderNo?: string;
    /** 第三方单号(主要应用场景 柠檬茶 在flipos 开有 美团饿了么 平台对接，这里三方单号指 饿了嘛，美团 单号) */
    thirdPartyPlatformBill?: string;
    /** 订单状态 */
    tradeStatus?: string;
    /** 下单时间 */
    tradeTime?: string;
    /** 订单类型 1:网店销售 2线下零售 3售后换货 4批发业务 5保修换新 6保修完成 7订单补发; */
    tradeType?: string;
    /** TODO: 订单日志暂无 */
    operator?: any[];
  }

  interface reqRepushErp {
    /** 订单是否推erp 0:不推送 1:推送 */
    omsSwitch?: number;
    /** 平台ID 0:话梅订单; 1:柠檬茶; 2:马里昂巴; 3:自研pos; 4:美团非餐饮订单 */
    platformId?: string;
    /** 源单号 */
    srcOrderNo?: string;
  }

  interface resShopItem {
    /** 详细地址 */
    address?: string;
    /** 市 */
    city?: string;
    /** 区或者县 */
    county?: string;
    /** erp 对应门店code */
    erpStoreCode?: string;
    /** erp对应的门店仓库名称 */
    erpWarehouseName?: string;
    /** erp对应的门店仓库编号 */
    erpWarehouseNo?: string;
    /** flipos 对应门店id */
    fliposStoreId?: number;
    /** flipos对应的门店名称 */
    fliposStoreName?: string;
    id?: number;
    /** 门店对应oms 名称 */
    omsName?: string;
    /** 订单和售后是否传erp 0:不传 1:传 */
    omsSwitch?: number;
    /** 电话 */
    phone?: string;
    /** oms 处理方式 0:自动处理 1:需要审核 */
    processType?: number;
    /** 省 */
    province?: string;
    /** 所属平台 0：harry 1:柠檬茶 2：马里昂巴 */
    sourceFrom?: number;
  }

}
