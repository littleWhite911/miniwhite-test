import { ResPagination } from '@/types';
import largeOrderRequest from '../request/largeOrderRequest';

/** 订单列表 */
export async function getRetailOrderList(data: RetailOrder.reqRetailOrderList) {
  return largeOrderRequest<ResPagination<RetailOrder.resRetailOrderItem>>({
    url: '/largeOrder/trade/list',
    method: 'POST',
    loading: true,
    data,
  });
}

/** 订单详情 */
export async function getRetailOrderDetail(data: RetailOrder.reqRetailOrderDetail) {
  return largeOrderRequest<RetailOrder.resRetailOrderDetail>({
    url: '/largeOrder/trade/detail',
    method: 'POST',
    loading: true,
    data,
  });
}

/** 推送erp */
export async function respushErp(data: RetailOrder.reqRepushErp) {
  return largeOrderRequest({
    url: '/largeOrder/trade/repush',
    method: 'POST',
    loading: true,
    data,
  });
}

/** 获取门店列表 */
export async function getShopEnum(data: {
  pageNo: number;
  pageSize: number;
}) {
  return largeOrderRequest<RetailOrder.resShopItem[]>({
    url: '/largeOrder/shop/list',
    method: 'POST',
    loading: true,
    data,
  });
}

/** 获取仓库列表 */
export async function getWarehouseEnum(data: {
  pageNo: number;
  pageSize: number;
}) {
  return largeOrderRequest<RetailOrder.resShopItem[]>({
    url: '/largeOrder/warehouse/list',
    method: 'POST',
    loading: true,
    data,
  });
}
