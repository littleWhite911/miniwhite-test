import { PageContainer, ProDescriptions, ProTable } from '@ant-design/pro-components';
import { Card } from 'antd';
import { useEffect, useState } from 'react';
import { connect, Dispatch, history } from 'umi';
import DetailPageHeader from '@/components/DetailPageHeader';
import { getRetailOrderDetail } from '@/service/order';
import { BusinessTypeEnum, CouponTypeEnum, PlatformIdEnum, SourceChannelEnum, TradeStatusEnum, TradeTypeEnum } from '../retailOrderList/enum';
import { OrderModelState } from '@/models/order';

const RetailOrderDetail = ({
  warehouseEnum,
  dispatch
}: {
  warehouseEnum: Record<string, string>;
  dispatch: Dispatch;
}) => {
  const { query = {} } = history.location;
  const { platformId, srcOrderId, srcOrderNo } = query as any;

  const [detail, setDetail] = useState<RetailOrder.resRetailOrderDetail>({});

  useEffect(() => {
    dispatch({
      type: 'order/getWarehouseEnum'
    });
    getDetail();
  }, []);

  const getDetail = async () => {

    const res = await getRetailOrderDetail({
      platformId,
      srcOrderId,
      srcOrderNo
    });
    res.items = res.items?.map((v, i) => ({
      ...v,
      key: i
    }));
    res.discounts = res.discounts?.map((v, i) => ({
      ...v,
      key: i
    }));
    res.pays = res.pays?.map((v, i) => ({
      ...v,
      key: i
    }));
    setDetail(res);
  };

  return (
    <PageContainer title={<DetailPageHeader headerName="零售订单详情" />}>
      <Card>
        <ProDescriptions
          title="订单基本信息"
          dataSource={detail}
          columns={[{
            title: '原始单号',
            key: 'srcOrderNo',
            dataIndex: 'srcOrderNo',
          }, {
            title: '第三方平台单号',
            key: 'thirdPartyPlatformBill',
            dataIndex: 'thirdPartyPlatformBill',
          }, {
            title: '业务类型',
            key: 'businessType',
            dataIndex: 'businessType',
            valueEnum: BusinessTypeEnum,
          }, {
            title: '订单类型',
            key: 'tradeType',
            dataIndex: 'tradeType',
            valueEnum: TradeTypeEnum,
          }, {
            title: '订单状态',
            key: 'tradeStatus',
            dataIndex: 'tradeStatus',
            valueEnum: TradeStatusEnum,
          }, {
            title: '店铺',
            key: 'fliposStoreName',
            dataIndex: 'fliposStoreName',
          }, {
            title: '来源渠道',
            key: 'sourceChannel',
            dataIndex: 'sourceChannel',
            valueEnum: SourceChannelEnum,
          }, {
            title: '平台',
            key: 'platformId',
            dataIndex: 'platformId',
            valueEnum: PlatformIdEnum,
          }, {
            title: '支付方式',
            key: 'payType',
            dataIndex: 'payType',
          }, {
            title: '支付时间',
            key: 'payTime',
            dataIndex: 'payTime',
          }, {
            title: '下单时间',
            key: 'tradeTime',
            dataIndex: 'tradeTime',
          }, {
            title: '创建时间',
            key: 'accessTime',
            dataIndex: 'accessTime',
          }, {
            title: '仓库',
            key: 'erpWarehouseNo',
            dataIndex: 'erpWarehouseNo',
            valueEnum: warehouseEnum
          }, {
            title: '快递公司',
            key: 'courierCompany',
            dataIndex: 'courierCompany',
          }, {
            title: '快递单号',
            key: 'courierNumber',
            dataIndex: 'courierNumber',
          }, {
            title: '服务类型',
            key: 'serviceType',
            dataIndex: 'serviceType',
          }, {
            title: '收银员ID',
            key: 'handlerId',
            dataIndex: 'handlerId',
          }, {
            title: '买家留言',
            key: 'remark',
            dataIndex: 'remark',
          }]}
        />
        <ProDescriptions
          title="收货人信息"
          dataSource={detail.receiver}
          columns={[{
            title: '收货人',
            key: 'receiverName',
            dataIndex: 'receiverName',
          }, {
            title: '性别',
            key: 'receiverSex',
            dataIndex: 'receiverSex',
          }, {
            title: '手机号',
            key: 'receiverMobile',
            dataIndex: 'receiverMobile',
          }, {
            title: '会员号',
            key: 'mrVipNumber',
            dataIndex: 'mrVipNumber',
          }, {
            title: '地址',
            key: 'receiverAddress',
            dataIndex: 'receiverAddress',
          }]}
        />
        <ProTable
          className="detail-protable"
          headerTitle="商品明细"
          search={false}
          dataSource={detail.items}
          pagination={false}
          scroll={{ x: 1200 }}
          columns={[{
            title: '子订单号',
            key: 'oid',
            dataIndex: 'oid',
          }, {
            title: '商家编码',
            key: 'sku',
            dataIndex: 'sku',
          }, {
            title: '商品名称',
            key: 'spuName',
            dataIndex: 'spuName',
          }, {
            title: '商品规格',
            key: 'skuName',
            dataIndex: 'skuName',
          }, {
            title: '是否赠品',
            key: 'giftFlag',
            dataIndex: 'giftFlag',
          }, {
            title: '是否组合商品',
            key: 'assemblyFlag',
            dataIndex: 'assemblyFlag',
          }, {
            title: '组合商品编码',
            key: 'assemblyCode',
            dataIndex: 'assemblyCode',
          }, {
            title: '数量',
            key: 'num',
            dataIndex: 'num',
          }, {
            title: '原始单价',
            key: 'originalPrice',
            dataIndex: 'originalPrice',
          }, {
            title: '销售单价',
            key: 'payPrice',
            dataIndex: 'payPrice',
          }, {
            title: '优惠金额',
            key: 'discountAmount',
            dataIndex: 'discountAmount',
          }, {
            title: '实付金额',
            key: 'totalPrice',
            dataIndex: 'totalPrice',
          }, {
            title: '服务类型',
            key: 'serviceType',
            dataIndex: 'serviceType',
          }]} />
        <ProTable
          className="detail-protable"
          headerTitle="优惠信息"
          search={false}
          pagination={false}
          dataSource={detail.discounts}
          columns={[{
            title: '优惠主体',
            key: 'subject',
            dataIndex: 'subject',
          }, {
            title: '商家编码',
            key: 'sku',
            dataIndex: 'sku',
          }, {
            title: '优惠分类',
            key: 'category',
            dataIndex: 'category',
          }, {
            title: '优惠名称',
            key: 'couponName',
            dataIndex: 'couponName',
          }, {
            title: '优惠类型',
            key: 'couponType',
            dataIndex: 'couponType',
            valueEnum: CouponTypeEnum,
          }, {
            title: '优惠金额',
            key: 'couponAmount',
            dataIndex: 'couponAmount',
          }]} />
        <ProDescriptions
          title="金额信息"
          dataSource={detail.price}
          columns={[{
            title: '订单总金额',
            key: 'originalPrice',
            dataIndex: 'originalPrice',
          }, {
            title: '支付金额',
            key: 'payPrice',
            dataIndex: 'payPrice',
          }, {
            title: '应收金额',
            key: 'receivable',
            dataIndex: 'receivable',
          }, {
            title: '抹零',
            key: 'adjustment',
            dataIndex: 'adjustment',
          }, {
            title: '赠送金额',
            key: 'giftAmount',
            dataIndex: 'giftAmount',
          }, {
            title: '优惠金额',
            key: 'discountAmount',
            dataIndex: 'discountAmount',
          }, {
            title: '平台服务费',
            key: 'commission',
            dataIndex: 'commission',
          }, {
            title: '配送费',
            key: 'deliveryFee',
            dataIndex: 'deliveryFee',
          }]}
        />
        <ProTable
          className="detail-protable"
          headerTitle="支付信息"
          search={false}
          pagination={false}
          dataSource={detail.pays}
          columns={[{
            title: '支付方式',
            key: 'payType',
            dataIndex: 'payType',
          }, {
            title: '支付金额',
            key: 'amount',
            dataIndex: 'amount',
          }, {
            title: '支付编码',
            key: 'payChannel',
            dataIndex: 'payChannel',
          }, {
            title: '订单号',
            key: 'payNo',
            dataIndex: 'payNo',
          }, {
            title: '支付明细ID',
            key: 'flow',
            dataIndex: 'flow',
          }]} />
        <ProTable
          className="detail-protable"
          headerTitle="订单日志"
          search={false}
          pagination={false}
          dataSource={detail.operator}
          columns={[{
            title: '操作名称',
            key: 'operateType',
            dataIndex: 'operateType',
          }, {
            title: '描述',
            key: 'description',
            dataIndex: 'description',
          }, {
            title: '操作人',
            key: 'operator',
            dataIndex: 'operator',
          }, {
            title: '操作时间',
            key: 'operateTime',
            dataIndex: 'operateTime',
          }]} />
      </Card>
    </PageContainer>
  );
};

export default connect(({ order }: { order: OrderModelState }) => ({
  warehouseEnum: order.warehouseEnum,
}))(RetailOrderDetail);