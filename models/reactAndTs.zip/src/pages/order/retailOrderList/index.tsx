import { useEffect, useRef, useState } from 'react';
import { Button, Modal, notification, Typography } from 'antd';
import type { ProColumns, ActionType } from '@ant-design/pro-table';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import { connect, Dispatch, history } from 'umi';
import {
  tableCollapseRender,
  tablePagination,
  tableSearchRender,
} from '@/utils/common';
import { getRetailOrderList, respushErp } from '@/service/order';
import { BusinessTypeEnum, PlatformIdEnum, PushStatusEnum, SourceChannelEnum, TradeStatusEnum, TradeTypeEnum } from './enum';
import { OrderModelState } from '@/models/order';
import { EnumType } from '@/types';

const { Link } = Typography;
const { confirm } = Modal;

const RetailOrderList = ({
  shopEnum,
  warehouseEnum,
  dispatch
}: {
  shopEnum: Record<string, string>;
  warehouseEnum: Record<string, string>;
  dispatch: Dispatch;
}) => {
  useEffect(() => {
    dispatch({
      type: 'order/getShopEnum'
    });
    dispatch({
      type: 'order/getWarehouseEnum'
    });
  }, []);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [selectedRows, setSelectedRows] = useState<RetailOrder.resRetailOrderItem[]>([]);
  const columns: ProColumns<RetailOrder.resRetailOrderItem>[] = [
    // 搜索列
    {
      title: '原始单号',
      dataIndex: 'srcOrderNo',
      hideInTable: true,
    },
    {
      title: '第三方平台单号',
      dataIndex: 'thirdPartyPlatformBill',
      hideInTable: true,
    },
    {
      title: '店铺',
      dataIndex: 'erpStoreCode',
      valueEnum: shopEnum,
      fieldProps: {
        showSearch: true,
      },
      hideInTable: true,
    },
    {
      title: '仓库',
      dataIndex: 'erpWarehouseNo',
      valueEnum: warehouseEnum,
      fieldProps: {
        showSearch: true,
      },
      hideInTable: true,
    },
    {
      title: '业务类型',
      dataIndex: 'businessType',
      valueEnum: BusinessTypeEnum,
      hideInTable: true,
    },
    {
      title: '平台',
      dataIndex: 'platformId',
      valueEnum: PlatformIdEnum,
      hideInTable: true,
    },
    {
      title: '来源渠道',
      dataIndex: 'sourceChannel',
      valueEnum: SourceChannelEnum,
      hideInTable: true,
    },
    {
      title: '支付金额',
      dataIndex: 'thirdPartyPaidPrice',
      hideInTable: true,
    },
    {
      title: '创建/下单时间',
      dataIndex: 'tradeTime',
      valueType: 'dateTimeRange',
      colSize: 1.5,
      hideInTable: true,
      search: {
        transform: (value) => ({
          tradeTimeBegin: value[0],
          tradeTimeEnd: value[1],
        }),
      },
    },
    {
      title: '推送状态',
      dataIndex: 'pushStatus',
      valueEnum: PushStatusEnum,
      hideInTable: true,
    },
    // 表格列
    {
      title: '原始单号',
      dataIndex: 'srcOrderNo',
      hideInSearch: true,
      render: (text, record) => <Link className="link-color underline" onClick={() => {
        history.push({
          pathname: 'retailOrderDetail',
          query: {
            platformId: record.platformId,
            srcOrderId: record.srcOrderId,
            srcOrderNo: record.srcOrderNo
          }
        });
      }}>{text}</Link>
    },
    {
      title: '下单时间',
      dataIndex: 'tradeTime',
      hideInSearch: true,
    },
    {
      title: '订单类型',
      dataIndex: 'tradeType',
      valueEnum: TradeTypeEnum,
      hideInSearch: true,
    },
    {
      title: '第三方平台单号',
      dataIndex: 'thirdPartyPlatformBill',
      hideInSearch: true,
    },
    {
      title: '店铺',
      dataIndex: 'fliposStoreName',
      hideInSearch: true,
    },
    {
      title: '业务类型',
      dataIndex: 'businessType',
      valueEnum: BusinessTypeEnum,
      hideInSearch: true,
    },
    {
      title: '订单状态',
      dataIndex: 'tradeStatus',
      valueEnum: TradeStatusEnum,
      hideInSearch: true,
    },
    {
      title: '收货人信息',
      dataIndex: '',
      hideInSearch: true,
    },
    {
      title: '仓库',
      dataIndex: 'erpWarehouseNo',
      hideInSearch: true,
      valueEnum: warehouseEnum
    },
    {
      title: '支付方式',
      dataIndex: '',
      hideInSearch: true,
    },
    {
      title: '用户支付金额',
      dataIndex: 'thirdPartyPaidPrice',
      hideInSearch: true,
    },
    {
      title: '总金额',
      dataIndex: 'originalAmount',
      hideInSearch: true,
    },
    {
      title: '服务方式',
      dataIndex: 'serviceType',
      hideInSearch: true,
    },
    {
      title: '订单备注',
      dataIndex: 'buyerMessage',
      hideInSearch: true,
    },
    {
      title: '平台',
      dataIndex: 'platformId',
      valueEnum: PlatformIdEnum,
      hideInSearch: true,
    },
    {
      title: '来源渠道',
      dataIndex: 'sourceChannel',
      valueEnum: SourceChannelEnum,
      hideInSearch: true,
    },
    {
      title: 'ERP推送状态',
      dataIndex: 'pushStatus',
      valueEnum: PushStatusEnum,
      hideInSearch: true,
    },
    {
      title: '更新时间',
      dataIndex: 'modified',
      hideInSearch: true,
    },
    {
      title: '创建时间',
      dataIndex: 'created',
      hideInSearch: true,
    },
    {
      title: '异常信息',
      dataIndex: 'errMess',
      hideInSearch: true,
    },
  ];

  const actionRef = useRef<ActionType>();

  const onSelectChange = (rowKeys: any, rows: any) => {
    if (rowKeys.length > 1) {
      notification.error({
        message: '只能选择一条订单'
      });
      return;
    }
    setSelectedRowKeys(rowKeys);
    setSelectedRows(rows);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };

  return (
    <PageContainer>
      <ProTable<RetailOrder.resRetailOrderItem>
        rowKey="srcOrderNo"
        scroll={{ x: 2500 }}
        columns={columns}
        actionRef={actionRef}
        cardBordered
        rowSelection={rowSelection}
        request={async (params = {}) => {
          const res = await getRetailOrderList({
            ...params,
            pageNo: params.current || 1,
          });
          return {
            success: true,
            data: res.records,
            total: res.total,
          };
        }}
        search={{
          labelWidth: 120,
          // span: tableColConfig,
          optionRender: tableSearchRender,
          collapseRender: tableCollapseRender,
        }}
        dateFormatter="string"
        tableAlertRender={false}
        toolBarRender={() => [
          <Button
            key="add"
            type="primary"
            onClick={() => {
              if (selectedRows.length !== 1) {
                notification.error({
                  message: '请选择一条订单'
                });
                return;
              }
              confirm({
                content: '确认要推送ERP吗？',
                okText: '确认',
                cancelText: '取消',
                onOk: async () => {
                  await respushErp({
                    omsSwitch: 1,
                    platformId: selectedRows[0].platformId,
                    srcOrderNo: selectedRows[0].srcOrderNo,
                  });
                  notification.success({
                    message: '推送成功'
                  });
                },
              });
            }}
          >
            推送ERP
          </Button>,
        ]}
        pagination={tablePagination}
      />
    </PageContainer>
  );
};

export default connect(({ order }: { order: OrderModelState }) => ({
  shopEnum: order.shopEnum,
  warehouseEnum: order.warehouseEnum,
}))(RetailOrderList);
;
