declare module '*.less';

export * from './interface';
