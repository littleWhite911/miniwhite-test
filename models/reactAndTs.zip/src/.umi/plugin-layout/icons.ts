// @ts-nocheck

  import SmileOutlined from '@ant-design/icons/es/icons/SmileOutlined'
  export default {
    SmileOutlined
  }