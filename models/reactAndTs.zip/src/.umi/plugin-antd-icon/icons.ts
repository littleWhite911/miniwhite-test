// @ts-nocheck

import SmileOutlined from '@ant-design/icons/SmileOutlined'

export default {
  SmileOutlined
}
    