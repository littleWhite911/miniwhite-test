(self["webpackChunkbusiness_end_order"] = self["webpackChunkbusiness_end_order"] || []).push([["mf-dep_src_umi_core_umiExports_ts"],{

/***/ "./src/.umi/core/history.ts":
/*!**********************************!*\
  !*** ./src/.umi/core/history.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createHistory": function() { return /* binding */ createHistory; },
/* harmony export */   "setCreateHistoryOptions": function() { return /* binding */ setCreateHistoryOptions; },
/* harmony export */   "getCreateHistoryOptions": function() { return /* binding */ getCreateHistoryOptions; },
/* harmony export */   "history": function() { return /* binding */ history; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@umijs/runtime */ "./node_modules/history-with-query/esm/history.js");

// @ts-nocheck

var _filehash = "TUoK";
var options = {
  "basename": "/business-end-order"
};

if (window.routerBase) {
  options.basename = window.routerBase;
} // remove initial history because of ssr


var history = ({"NODE_ENV":"development"}).__IS_SERVER ? null : (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_1__.createBrowserHistory)(options);
var createHistory = function createHistory() {
  var hotReload = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

  if (!hotReload) {
    switch (options.type) {
      case 'memory':
        history = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_1__.createMemoryHistory)(options);
        break;

      case 'hash':
        history = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_1__.createHashHistory)(options);
        break;

      case 'browser':
        history = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_1__.createBrowserHistory)(options);
        break;

      default:
        history = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_1__.createBrowserHistory)(options);
    }
  }

  return history;
}; // 通常仅微前端场景需要调用这个 API

var setCreateHistoryOptions = function setCreateHistoryOptions() {
  var newOpts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  options = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)({}, options), newOpts);
}; // 获取 history options 运行时配置

var getCreateHistoryOptions = function getCreateHistoryOptions() {
  return options;
};


/***/ }),

/***/ "./src/.umi/core/plugin.ts":
/*!*********************************!*\
  !*** ./src/.umi/core/plugin.ts ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "plugin": function() { return /* binding */ plugin; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/runtime */ "./node_modules/@umijs/runtime/dist/index.esm.js");
// @ts-nocheck

var _filehash = "1Cqk";
var plugin = new _Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_0__.Plugin({
  validKeys: ['modifyClientRenderOpts', 'patchRoutes', 'rootContainer', 'render', 'onRouteChange', '__mfsu', 'dva', 'getInitialState', 'initialStateConfig', 'layout', 'layoutActionRef', 'request', 'qiankun']
});


/***/ }),

/***/ "./src/.umi/core/umiExports.ts":
/*!*************************************!*\
  !*** ./src/.umi/core/umiExports.ts ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "history": function() { return /* reexport safe */ _history__WEBPACK_IMPORTED_MODULE_0__.history; },
/* harmony export */   "setCreateHistoryOptions": function() { return /* reexport safe */ _history__WEBPACK_IMPORTED_MODULE_0__.setCreateHistoryOptions; },
/* harmony export */   "getCreateHistoryOptions": function() { return /* reexport safe */ _history__WEBPACK_IMPORTED_MODULE_0__.getCreateHistoryOptions; },
/* harmony export */   "plugin": function() { return /* reexport safe */ _plugin__WEBPACK_IMPORTED_MODULE_1__.plugin; },
/* harmony export */   "Access": function() { return /* reexport safe */ _plugin_access_access__WEBPACK_IMPORTED_MODULE_2__.Access; },
/* harmony export */   "traverseModifyRoutes": function() { return /* reexport safe */ _plugin_access_access__WEBPACK_IMPORTED_MODULE_2__.traverseModifyRoutes; },
/* harmony export */   "useAccess": function() { return /* reexport safe */ _plugin_access_access__WEBPACK_IMPORTED_MODULE_2__.useAccess; },
/* harmony export */   "connect": function() { return /* reexport safe */ _plugin_dva_exports__WEBPACK_IMPORTED_MODULE_3__.connect; },
/* harmony export */   "getDvaApp": function() { return /* reexport safe */ _plugin_dva_exports__WEBPACK_IMPORTED_MODULE_3__.getDvaApp; },
/* harmony export */   "useDispatch": function() { return /* reexport safe */ _plugin_dva_exports__WEBPACK_IMPORTED_MODULE_3__.useDispatch; },
/* harmony export */   "useSelector": function() { return /* reexport safe */ _plugin_dva_exports__WEBPACK_IMPORTED_MODULE_3__.useSelector; },
/* harmony export */   "useStore": function() { return /* reexport safe */ _plugin_dva_exports__WEBPACK_IMPORTED_MODULE_3__.useStore; },
/* harmony export */   "__PLUGIN_INITIAL_STATE": function() { return /* reexport safe */ _plugin_initial_state_exports__WEBPACK_IMPORTED_MODULE_5__.__PLUGIN_INITIAL_STATE; },
/* harmony export */   "useModel": function() { return /* reexport safe */ _plugin_model_useModel__WEBPACK_IMPORTED_MODULE_7__.useModel; },
/* harmony export */   "ErrorShowType": function() { return /* reexport safe */ _plugin_request_request__WEBPACK_IMPORTED_MODULE_8__.ErrorShowType; },
/* harmony export */   "UseRequestProvider": function() { return /* reexport safe */ _plugin_request_request__WEBPACK_IMPORTED_MODULE_8__.UseRequestProvider; },
/* harmony export */   "request": function() { return /* reexport safe */ _plugin_request_request__WEBPACK_IMPORTED_MODULE_8__.request; },
/* harmony export */   "useRequest": function() { return /* reexport safe */ _plugin_request_request__WEBPACK_IMPORTED_MODULE_8__.useRequest; },
/* harmony export */   "Helmet": function() { return /* reexport safe */ _plugin_helmet_exports__WEBPACK_IMPORTED_MODULE_9__.Helmet; },
/* harmony export */   "useRootExports": function() { return /* reexport safe */ _plugin_qiankun_qiankunContext__WEBPACK_IMPORTED_MODULE_10__.useRootExports; },
/* harmony export */   "connectMaster": function() { return /* reexport safe */ _plugin_qiankun_connectMaster__WEBPACK_IMPORTED_MODULE_11__.connectMaster; },
/* harmony export */   "KeepAlive": function() { return /* reexport safe */ react_activation__WEBPACK_IMPORTED_MODULE_12__.KeepAlive; },
/* harmony export */   "useActivate": function() { return /* reexport safe */ react_activation__WEBPACK_IMPORTED_MODULE_12__.useActivate; },
/* harmony export */   "useUnactivate": function() { return /* reexport safe */ react_activation__WEBPACK_IMPORTED_MODULE_12__.useUnactivate; },
/* harmony export */   "withActivation": function() { return /* reexport safe */ react_activation__WEBPACK_IMPORTED_MODULE_12__.withActivation; },
/* harmony export */   "withAliveScope": function() { return /* reexport safe */ react_activation__WEBPACK_IMPORTED_MODULE_12__.withAliveScope; },
/* harmony export */   "useAliveController": function() { return /* reexport safe */ react_activation__WEBPACK_IMPORTED_MODULE_12__.useAliveController; }
/* harmony export */ });
/* harmony import */ var _history__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./history */ "./src/.umi/core/history.ts");
/* harmony import */ var _plugin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./plugin */ "./src/.umi/core/plugin.ts");
/* harmony import */ var _plugin_access_access__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../plugin-access/access */ "./src/.umi/plugin-access/access.tsx");
/* harmony import */ var _plugin_dva_exports__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../plugin-dva/exports */ "./src/.umi/plugin-dva/exports.ts");
/* harmony import */ var _plugin_dva_connect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../plugin-dva/connect */ "./src/.umi/plugin-dva/connect.ts");
/* harmony import */ var _plugin_initial_state_exports__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../plugin-initial-state/exports */ "./src/.umi/plugin-initial-state/exports.ts");
/* harmony import */ var _plugin_layout_layoutExports__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../plugin-layout/layoutExports */ "./src/.umi/plugin-layout/layoutExports.ts");
/* harmony import */ var _plugin_model_useModel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../plugin-model/useModel */ "./src/.umi/plugin-model/useModel.tsx");
/* harmony import */ var _plugin_request_request__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../plugin-request/request */ "./src/.umi/plugin-request/request.ts");
/* harmony import */ var _plugin_helmet_exports__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../plugin-helmet/exports */ "./src/.umi/plugin-helmet/exports.ts");
/* harmony import */ var _plugin_qiankun_qiankunContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../plugin-qiankun/qiankunContext */ "./src/.umi/plugin-qiankun/qiankunContext.js");
/* harmony import */ var _plugin_qiankun_connectMaster__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../plugin-qiankun/connectMaster */ "./src/.umi/plugin-qiankun/connectMaster.tsx");
/* harmony import */ var react_activation__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-activation */ "./node_modules/react-activation/lib/index.js");
var _filehash = "jmsk";
// @ts-nocheck














/***/ }),

/***/ "./src/.umi/plugin-access/access.tsx":
/*!*******************************************!*\
  !*** ./src/.umi/plugin-access/access.tsx ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "traverseModifyRoutes": function() { return /* reexport safe */ _runtimeUtil__WEBPACK_IMPORTED_MODULE_2__.traverseModifyRoutes; },
/* harmony export */   "useAccess": function() { return /* binding */ useAccess; },
/* harmony export */   "Access": function() { return /* binding */ Access; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./context */ "./src/.umi/plugin-access/context.ts");
/* harmony import */ var _runtimeUtil__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./runtimeUtil */ "./src/.umi/plugin-access/runtimeUtil.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
// @ts-nocheck





var _filehash = "NaHl";

var useAccess = function useAccess() {
  var access = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_context__WEBPACK_IMPORTED_MODULE_1__.default);
  return access;
};
var Access = function Access(props) {
  var accessible = props.accessible,
      fallback = props.fallback,
      children = props.children;

  if ( true && typeof accessible === 'function') {
    console.warn('[plugin-access]: provided "accessible" prop is a function named "' + accessible.name + '" instead of a boolean, maybe you need check it.');
  }

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: accessible ? children : fallback
  }, void 0, false);
};

/***/ }),

/***/ "./src/.umi/plugin-access/context.ts":
/*!*******************************************!*\
  !*** ./src/.umi/plugin-access/context.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
// @ts-nocheck

var _filehash = "mn/2";
var AccessContext = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createContext(null);
/* harmony default export */ __webpack_exports__["default"] = (AccessContext);

/***/ }),

/***/ "./src/.umi/plugin-access/runtimeUtil.ts":
/*!***********************************************!*\
  !*** ./src/.umi/plugin-access/runtimeUtil.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "traverseModifyRoutes": function() { return /* binding */ traverseModifyRoutes; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js");


// @ts-nocheck
var _filehash = "+aVg";
var oldChildrenPropsName = 'routes';
function traverseModifyRoutes(childrenList, access) {
  var resultChildrenList = [].concat(childrenList).map(function (resultRoute) {
    var childList = resultRoute.children || resultRoute[oldChildrenPropsName];

    if (childList && childList !== null && childList !== void 0 && childList.length) {
      return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__.default)({}, resultRoute), {}, (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__.default)({
        children: childList === null || childList === void 0 ? void 0 : childList.map(function (route) {
          return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__.default)({}, route);
        })
      }, oldChildrenPropsName, childList === null || childList === void 0 ? void 0 : childList.map(function (route) {
        return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__.default)({}, route);
      })));
    }

    return resultRoute;
  });
  return resultChildrenList.map(function (currentRoute) {
    var currentRouteAccessible = typeof currentRoute.unaccessible === 'boolean' ? !currentRoute.unaccessible : true; // 判断路由是否有权限的具体代码

    if (currentRoute && currentRoute.access) {
      if (typeof currentRoute.access !== 'string') {
        throw new Error('[plugin-access]: "access" field set in "' + currentRoute.path + '" route should be a string.');
      }

      var accessProp = access[currentRoute.access]; // 如果是方法需要执行以下

      if (typeof accessProp === 'function') {
        currentRouteAccessible = accessProp(currentRoute);
      } else if (typeof accessProp === 'boolean') {
        // 不是方法就直接 copy
        currentRouteAccessible = accessProp;
      }

      currentRoute.unaccessible = !currentRouteAccessible;
    }

    var childList = currentRoute.children || currentRoute[oldChildrenPropsName]; // 筛选子路由

    if (childList && Array.isArray(childList) && childList.length) {
      if (!Array.isArray(childList)) {
        return currentRoute;
      } // 父亲没权限，理论上每个孩子都没权限
      // 可能有打平 的事情发生，所以都执行一下


      childList.forEach(function (childRoute) {
        childRoute.unaccessible = !currentRouteAccessible;
      });
      var finallyChildList = traverseModifyRoutes(childList, access); // 如果每个子节点都没有权限，那么自己也属于没有权限

      var isAllChildChildrenUnaccessible = Array.isArray(finallyChildList) && finallyChildList.every(function (route) {
        return route.unaccessible;
      });

      if (!currentRoute.unaccessible && isAllChildChildrenUnaccessible) {
        currentRoute.unaccessible = true;
      }

      if (finallyChildList && (finallyChildList === null || finallyChildList === void 0 ? void 0 : finallyChildList.length) > 0) {
        return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__.default)({}, currentRoute), {}, (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__.default)({
          children: finallyChildList
        }, oldChildrenPropsName, finallyChildList));
      }

      delete currentRoute.routes;
      delete currentRoute.children;
    }

    return currentRoute;
  });
}

/***/ }),

/***/ "./src/.umi/plugin-dva/connect.ts":
/*!****************************************!*\
  !*** ./src/.umi/plugin-dva/connect.ts ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_src_models_order__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/models/order */ "./src/models/order.ts");
// @ts-nocheck
var _filehash = "tltl";



/***/ }),

/***/ "./src/.umi/plugin-dva/dva.ts":
/*!************************************!*\
  !*** ./src/.umi/plugin-dva/dva.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_onCreate": function() { return /* binding */ _onCreate; },
/* harmony export */   "getApp": function() { return /* binding */ getApp; },
/* harmony export */   "_DvaContainer": function() { return /* binding */ _DvaContainer; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./node_modules/@umijs/runtime */ "./node_modules/@umijs/runtime/dist/index.esm.js");
/* harmony import */ var dva__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! dva */ "./node_modules/dva/dist/index.esm.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_dva_loading_dist_index_esm_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./node_modules/dva-loading/dist/index.esm.js */ "./node_modules/dva-loading/dist/index.esm.js");
/* harmony import */ var _core_umiExports__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../core/umiExports */ "./src/.umi/core/umiExports.ts");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_src_models_order_ts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./src/models/order.ts */ "./src/models/order.ts");





// @ts-nocheck


 // @ts-ignore




var _filehash = "9bOy";
var app = null;
function _onCreate() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var runtimeDva = _core_umiExports__WEBPACK_IMPORTED_MODULE_6__.plugin.applyPlugins({
    key: 'dva',
    type: _Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_8__.ApplyPluginsType.modify,
    initialValue: {}
  });
  app = (0,dva__WEBPACK_IMPORTED_MODULE_9__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__.default)({
    history: _core_umiExports__WEBPACK_IMPORTED_MODULE_6__.history
  }, runtimeDva.config || {}), typeof window !== 'undefined' && window.g_useSSR ? {
    initialState: window.g_initialProps
  } : {}), options || {}));
  app.use((0,_Users_hansc_Documents_project_business_end_order_node_modules_dva_loading_dist_index_esm_js__WEBPACK_IMPORTED_MODULE_10__.default)());
  (runtimeDva.plugins || []).forEach(function (plugin) {
    app.use(plugin);
  });
  app.model((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__.default)({
    namespace: 'order'
  }, _Users_hansc_Documents_project_business_end_order_src_models_order_ts__WEBPACK_IMPORTED_MODULE_7__.default));
  return app;
}
function getApp() {
  return app;
}
/**
 * whether browser env
 * 
 * @returns boolean
 */

function isBrowser() {
  return typeof window !== 'undefined' && typeof window.document !== 'undefined' && typeof window.document.createElement !== 'undefined';
}

var _DvaContainer = /*#__PURE__*/function (_Component) {
  (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_2__.default)(_DvaContainer, _Component);

  var _super = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_3__.default)(_DvaContainer);

  function _DvaContainer(props) {
    var _this;

    (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__.default)(this, _DvaContainer);

    _this = _super.call(this, props); // run only in client, avoid override server _onCreate()

    if (isBrowser()) {
      _onCreate();
    }

    return _this;
  }

  (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__.default)(_DvaContainer, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      var app = getApp();

      app._models.forEach(function (model) {
        app.unmodel(model.namespace);
      });

      app._models = [];

      try {
        // 释放 app，for gc
        // immer 场景 app 是 read-only 的，这里 try catch 一下
        app = null;
      } catch (e) {
        console.error(e);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var app = getApp();
      app.router(function () {
        return _this2.props.children;
      });
      return app.start()();
    }
  }]);

  return _DvaContainer;
}(react__WEBPACK_IMPORTED_MODULE_5__.Component);

/***/ }),

/***/ "./src/.umi/plugin-dva/exports.ts":
/*!****************************************!*\
  !*** ./src/.umi/plugin-dva/exports.ts ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "connect": function() { return /* reexport safe */ dva__WEBPACK_IMPORTED_MODULE_0__.connect; },
/* harmony export */   "useDispatch": function() { return /* reexport safe */ dva__WEBPACK_IMPORTED_MODULE_0__.useDispatch; },
/* harmony export */   "useStore": function() { return /* reexport safe */ dva__WEBPACK_IMPORTED_MODULE_0__.useStore; },
/* harmony export */   "useSelector": function() { return /* reexport safe */ dva__WEBPACK_IMPORTED_MODULE_0__.useSelector; },
/* harmony export */   "getDvaApp": function() { return /* reexport safe */ _dva__WEBPACK_IMPORTED_MODULE_1__.getApp; }
/* harmony export */ });
/* harmony import */ var dva__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! dva */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _dva__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dva */ "./src/.umi/plugin-dva/dva.ts");
var _filehash = "bAb4";
// @ts-nocheck



/***/ }),

/***/ "./src/.umi/plugin-helmet/exports.ts":
/*!*******************************************!*\
  !*** ./src/.umi/plugin-helmet/exports.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Helmet": function() { return /* reexport safe */ _Users_hansc_Documents_project_business_end_order_node_modules_react_helmet__WEBPACK_IMPORTED_MODULE_0__.Helmet; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_react_helmet__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/react-helmet */ "./node_modules/react-helmet/es/Helmet.js");
var _filehash = "Sdya";
// @ts-nocheck
// @ts-ignore


/***/ }),

/***/ "./src/.umi/plugin-initial-state/exports.ts":
/*!**************************************************!*\
  !*** ./src/.umi/plugin-initial-state/exports.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__PLUGIN_INITIAL_STATE": function() { return /* binding */ __PLUGIN_INITIAL_STATE; }
/* harmony export */ });
// @ts-nocheck
// @ts-ignore
var _filehash = "rQTY";
var __PLUGIN_INITIAL_STATE = 1;

/***/ }),

/***/ "./src/.umi/plugin-layout/layoutExports.ts":
/*!*************************************************!*\
  !*** ./src/.umi/plugin-layout/layoutExports.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// @ts-nocheck
var _filehash = "qWSk";
// avoid `export *` error
/* harmony default export */ __webpack_exports__["default"] = ({});

/***/ }),

/***/ "./src/.umi/plugin-model/helpers/constant.tsx":
/*!****************************************************!*\
  !*** ./src/.umi/plugin-model/helpers/constant.tsx ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UmiContext": function() { return /* binding */ UmiContext; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
// @ts-nocheck

var _filehash = "Vbvd";
var UmiContext = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createContext({});

/***/ }),

/***/ "./src/.umi/plugin-model/useModel.tsx":
/*!********************************************!*\
  !*** ./src/.umi/plugin-model/useModel.tsx ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useModel": function() { return /* binding */ useModel; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_plugin_model_node_modules_fast_deep_equal_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@umijs/plugin-model/node_modules/fast-deep-equal/index.js */ "./node_modules/@umijs/plugin-model/node_modules/fast-deep-equal/index.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_plugin_model_node_modules_fast_deep_equal_index_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Users_hansc_Documents_project_business_end_order_node_modules_umijs_plugin_model_node_modules_fast_deep_equal_index_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _helpers_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./helpers/constant */ "./src/.umi/plugin-model/helpers/constant.tsx");

// @ts-nocheck
 // @ts-ignore

 // @ts-ignore


var _filehash = "p9XA";
function useModel(namespace, updater) {
  var dispatcher = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_helpers_constant__WEBPACK_IMPORTED_MODULE_3__.UmiContext);
  var updaterRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(updater);
  updaterRef.current = updater;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(function () {
    return updaterRef.current ? updaterRef.current(dispatcher.data[namespace]) : dispatcher.data[namespace];
  }),
      _useState2 = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__.default)(_useState, 2),
      state = _useState2[0],
      setState = _useState2[1];

  var stateRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(state);
  stateRef.current = state;
  var isMount = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(false);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    isMount.current = true;
    return function () {
      isMount.current = false;
    };
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    var handler = function handler(e) {
      if (!isMount.current) {
        // 如果 handler 执行过程中，组件被卸载了，则强制更新全局 data
        setTimeout(function () {
          dispatcher.data[namespace] = e;
          dispatcher.update(namespace);
        });
      } else {
        if (updater && updaterRef.current) {
          var currentState = updaterRef.current(e);
          var previousState = stateRef.current;

          if (!_Users_hansc_Documents_project_business_end_order_node_modules_umijs_plugin_model_node_modules_fast_deep_equal_index_js__WEBPACK_IMPORTED_MODULE_2___default()(currentState, previousState)) {
            setState(currentState);
          }
        } else {
          setState(e);
        }
      }
    };

    try {
      dispatcher.callbacks[namespace].add(handler);
      dispatcher.update(namespace);
    } catch (e) {
      dispatcher.callbacks[namespace] = new Set();
      dispatcher.callbacks[namespace].add(handler);
      dispatcher.update(namespace);
    }

    return function () {
      dispatcher.callbacks[namespace].delete(handler);
    };
  }, [namespace]);
  return state;
}
;

/***/ }),

/***/ "./src/.umi/plugin-qiankun/connectMaster.tsx":
/*!***************************************************!*\
  !*** ./src/.umi/plugin-qiankun/connectMaster.tsx ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "connectMaster": function() { return /* binding */ connectMaster; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var umi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! umi */ "./src/.umi/core/umiExports.ts");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var lodash_noop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash/noop */ "./node_modules/lodash/noop.js");
/* harmony import */ var lodash_noop__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_noop__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");


var _jsxFileName = "/Users/hansc/Documents/project/business-end-order/src/.umi/plugin-qiankun/connectMaster.tsx",
    _this = undefined;

// @ts-nocheck




var _filehash = "7QWl";

var connectMaster = function connectMaster(Component) {
  return function (props) {
    var masterProps = (umi__WEBPACK_IMPORTED_MODULE_4__.useModel || (lodash_noop__WEBPACK_IMPORTED_MODULE_2___default()))('@@qiankunStateFromMaster') || {};

    for (var _len = arguments.length, rest = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      rest[_key - 1] = arguments[_key];
    }

    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Component, (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)({}, props), rest), masterProps), {}, {
      _nk: "".concat(_filehash, "11")
    }), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 12
    }, _this);
  };
};



/***/ }),

/***/ "./src/.umi/plugin-qiankun/qiankunContext.js":
/*!***************************************************!*\
  !*** ./src/.umi/plugin-qiankun/qiankunContext.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Context": function() { return /* binding */ Context; },
/* harmony export */   "useRootExports": function() { return /* binding */ useRootExports; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");

var _filehash = "jfXo";
var Context = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
function useRootExports() {
  if (true) {
    console.error('[@umijs/plugin-qiankun] Deprecated: useRootExports 通信方式不再推荐，并将在后续版本中移除，请尽快升级到新的应用通信模式，以获得更好的开发体验。详见 https://umijs.org/plugins/plugin-qiankun#%E7%88%B6%E5%AD%90%E5%BA%94%E7%94%A8%E9%80%9A%E8%AE%AF');
  }

  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(Context);
}

/***/ }),

/***/ "./src/.umi/plugin-request/request.ts":
/*!********************************************!*\
  !*** ./src/.umi/plugin-request/request.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ErrorShowType": function() { return /* binding */ ErrorShowType; },
/* harmony export */   "request": function() { return /* binding */ request; },
/* harmony export */   "useRequest": function() { return /* binding */ useRequest; },
/* harmony export */   "UseRequestProvider": function() { return /* reexport safe */ _Users_hansc_Documents_project_business_end_order_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_7__.UseRequestProvider; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectWithoutProperties_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umi_request__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/umi-request */ "./node_modules/umi-request/dist/index.esm.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./node_modules/@umijs/runtime */ "./node_modules/@umijs/runtime/dist/index.esm.js");
/* harmony import */ var _core_umiExports__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../core/umiExports */ "./src/.umi/core/umiExports.ts");
/* harmony import */ var _umijs_plugin_request_lib_ui__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @umijs/plugin-request/lib/ui */ "./node_modules/@umijs/plugin-request/lib/ui/index.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@ahooksjs/use-request */ "./node_modules/@ahooksjs/use-request/es/index.js");




var _excluded = ["url"];
// @ts-nocheck

/**
 * Base on https://github.com/umijs//Users/hansc/Documents/project/business-end-order/node_modules/umi-request
 */
 // @ts-ignore


 // decoupling with antd UI library, you can using `alias` modify the ui methods
// @ts-ignore



var _filehash = "rSBf";

function useRequest(service) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return (0,_Users_hansc_Documents_project_business_end_order_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_7__.default)(service, (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__.default)({
    formatResult: function formatResult(result) {
      return result === null || result === void 0 ? void 0 : result.data;
    },
    requestMethod: function requestMethod(requestOptions) {
      if (typeof requestOptions === 'string') {
        return request(requestOptions);
      }

      if (typeof requestOptions === 'object') {
        var _url = requestOptions.url,
            rest = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectWithoutProperties_js__WEBPACK_IMPORTED_MODULE_2__.default)(requestOptions, _excluded);

        return request(_url, rest);
      }

      throw new Error('request options error');
    }
  }, options));
}

var ErrorShowType;

(function (ErrorShowType) {
  ErrorShowType[ErrorShowType["SILENT"] = 0] = "SILENT";
  ErrorShowType[ErrorShowType["WARN_MESSAGE"] = 1] = "WARN_MESSAGE";
  ErrorShowType[ErrorShowType["ERROR_MESSAGE"] = 2] = "ERROR_MESSAGE";
  ErrorShowType[ErrorShowType["NOTIFICATION"] = 4] = "NOTIFICATION";
  ErrorShowType[ErrorShowType["REDIRECT"] = 9] = "REDIRECT";
})(ErrorShowType || (ErrorShowType = {}));

var DEFAULT_ERROR_PAGE = '/exception';
var requestMethodInstance;

var getRequestMethod = function getRequestMethod() {
  var _requestConfig$errorC;

  if (requestMethodInstance) {
    // request method 已经示例化
    return requestMethodInstance;
  } // runtime 配置可能应为依赖顺序的问题在模块初始化的时候无法获取，所以需要封装一层在异步调用后初始化相关方法
  // 当用户的 app.ts 中依赖了该文件的情况下就该模块的初始化时间就会被提前，无法获取到运行时配置


  var requestConfig = _core_umiExports__WEBPACK_IMPORTED_MODULE_5__.plugin.applyPlugins({
    key: 'request',
    type: _Users_hansc_Documents_project_business_end_order_node_modules_umijs_runtime__WEBPACK_IMPORTED_MODULE_8__.ApplyPluginsType.modify,
    initialValue: {}
  });

  var errorAdaptor = ((_requestConfig$errorC = requestConfig.errorConfig) === null || _requestConfig$errorC === void 0 ? void 0 : _requestConfig$errorC.adaptor) || function (resData) {
    return resData;
  };

  requestMethodInstance = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umi_request__WEBPACK_IMPORTED_MODULE_4__.extend)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__.default)({
    errorHandler: function errorHandler(error) {
      var _error$request, _error$request$option, _errorInfo4;

      // @ts-ignore
      if (error !== null && error !== void 0 && (_error$request = error.request) !== null && _error$request !== void 0 && (_error$request$option = _error$request.options) !== null && _error$request$option !== void 0 && _error$request$option.skipErrorHandler) {
        throw error;
      }

      var errorInfo;

      if (error.name === 'ResponseError' && error.data && error.request) {
        var _errorInfo;

        var _ctx = {
          req: error.request,
          res: error.response
        };
        errorInfo = errorAdaptor(error.data, _ctx);
        error.message = ((_errorInfo = errorInfo) === null || _errorInfo === void 0 ? void 0 : _errorInfo.errorMessage) || error.message;
        error.data = error.data;
        error.info = errorInfo;
      }

      errorInfo = error.info;

      if (errorInfo) {
        var _errorInfo2, _errorInfo3, _requestConfig$errorC2;

        var errorMessage = (_errorInfo2 = errorInfo) === null || _errorInfo2 === void 0 ? void 0 : _errorInfo2.errorMessage;
        var errorCode = (_errorInfo3 = errorInfo) === null || _errorInfo3 === void 0 ? void 0 : _errorInfo3.errorCode;
        var errorPage = ((_requestConfig$errorC2 = requestConfig.errorConfig) === null || _requestConfig$errorC2 === void 0 ? void 0 : _requestConfig$errorC2.errorPage) || DEFAULT_ERROR_PAGE;

        switch ((_errorInfo4 = errorInfo) === null || _errorInfo4 === void 0 ? void 0 : _errorInfo4.showType) {
          case ErrorShowType.SILENT:
            // do nothing
            break;

          case ErrorShowType.WARN_MESSAGE:
            _umijs_plugin_request_lib_ui__WEBPACK_IMPORTED_MODULE_6__.message.warn(errorMessage);
            break;

          case ErrorShowType.ERROR_MESSAGE:
            _umijs_plugin_request_lib_ui__WEBPACK_IMPORTED_MODULE_6__.message.error(errorMessage);
            break;

          case ErrorShowType.NOTIFICATION:
            _umijs_plugin_request_lib_ui__WEBPACK_IMPORTED_MODULE_6__.notification.open({
              description: errorMessage,
              message: errorCode
            });
            break;

          case ErrorShowType.REDIRECT:
            // @ts-ignore
            _core_umiExports__WEBPACK_IMPORTED_MODULE_5__.history.push({
              pathname: errorPage,
              query: {
                errorCode: errorCode,
                errorMessage: errorMessage
              }
            }); // redirect to error page

            break;

          default:
            _umijs_plugin_request_lib_ui__WEBPACK_IMPORTED_MODULE_6__.message.error(errorMessage);
            break;
        }
      } else {
        _umijs_plugin_request_lib_ui__WEBPACK_IMPORTED_MODULE_6__.message.error(error.message || 'Request error, please retry.');
      }

      throw error;
    }
  }, requestConfig)); // 中间件统一错误处理
  // 后端返回格式 { success: boolean, data: any }
  // 按照项目具体情况修改该部分逻辑

  requestMethodInstance.use( /*#__PURE__*/function () {
    var _ref = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__.default)( /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().mark(function _callee(ctx, next) {
      var _req$options;

      var req, res, options, getResponse, resData, errorInfo, error;
      return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return next();

            case 2:
              req = ctx.req, res = ctx.res; // @ts-ignore

              if (!((_req$options = req.options) !== null && _req$options !== void 0 && _req$options.skipErrorHandler)) {
                _context.next = 5;
                break;
              }

              return _context.abrupt("return");

            case 5:
              options = req.options;
              getResponse = options.getResponse;
              resData = getResponse ? res.data : res;
              errorInfo = errorAdaptor(resData, ctx);

              if (!(errorInfo.success === false)) {
                _context.next = 16;
                break;
              }

              // 抛出错误到 errorHandler 中处理
              error = new Error(errorInfo.errorMessage);
              error.name = 'BizError';
              error.data = resData;
              error.info = errorInfo;
              error.response = res;
              throw error;

            case 16:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x, _x2) {
      return _ref.apply(this, arguments);
    };
  }()); // Add user custom middlewares

  var customMiddlewares = requestConfig.middlewares || [];
  customMiddlewares.forEach(function (mw) {
    requestMethodInstance.use(mw);
  }); // Add user custom interceptors

  var requestInterceptors = requestConfig.requestInterceptors || [];
  var responseInterceptors = requestConfig.responseInterceptors || [];
  requestInterceptors.map(function (ri) {
    requestMethodInstance.interceptors.request.use(ri);
  });
  responseInterceptors.map(function (ri) {
    requestMethodInstance.interceptors.response.use(ri);
  });
  return requestMethodInstance;
};

var request = function request(url, options) {
  var requestMethod = getRequestMethod();
  return requestMethod(url, options);
};



/***/ }),

/***/ "./src/models/order.ts":
/*!*****************************!*\
  !*** ./src/models/order.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _service_order__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/service/order */ "./src/service/order/index.ts");



var _filehash = "ZDFI";
var OrderModel = {
  namespace: 'order',
  state: {
    shopEnum: {},
    warehouseEnum: {}
  },
  effects: {
    getShopEnum: /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_1__.default)().mark(function getShopEnum(payload, _ref) {
      var _res$records;

      var call, put, res, enumObj;
      return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_1__.default)().wrap(function getShopEnum$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              call = _ref.call, put = _ref.put;
              _context.next = 3;
              return call(_service_order__WEBPACK_IMPORTED_MODULE_2__.getShopEnum, {
                pageNo: 1,
                pageSize: 99999
              });

            case 3:
              res = _context.sent;
              enumObj = {};
              (_res$records = res.records) === null || _res$records === void 0 ? void 0 : _res$records.forEach(function (v) {
                enumObj[v.erpStoreCode] = v.fliposStoreName;
              });
              _context.next = 8;
              return put({
                type: 'saveShopEnum',
                payload: {
                  shopEnum: enumObj
                }
              });

            case 8:
            case "end":
              return _context.stop();
          }
        }
      }, getShopEnum);
    }),
    getWarehouseEnum: /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_1__.default)().mark(function getWarehouseEnum(payload, _ref2) {
      var _res$records2;

      var call, put, res, enumObj;
      return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_1__.default)().wrap(function getWarehouseEnum$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              call = _ref2.call, put = _ref2.put;
              _context2.next = 3;
              return call(_service_order__WEBPACK_IMPORTED_MODULE_2__.getWarehouseEnum, {
                pageNo: 1,
                pageSize: 99999
              });

            case 3:
              res = _context2.sent;
              enumObj = {};
              (_res$records2 = res.records) === null || _res$records2 === void 0 ? void 0 : _res$records2.forEach(function (v) {
                enumObj[v.erpWarehouseNo] = v.erpWarehouseName;
              });
              _context2.next = 8;
              return put({
                type: 'saveWarehouseEnum',
                payload: {
                  warehouseEnum: enumObj
                }
              });

            case 8:
            case "end":
              return _context2.stop();
          }
        }
      }, getWarehouseEnum);
    })
  },
  reducers: {
    saveShopEnum: function saveShopEnum(state, action) {
      return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)({}, state), action.payload);
    },
    saveWarehouseEnum: function saveWarehouseEnum(state, action) {
      return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)((0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__.default)({}, state), action.payload);
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (OrderModel);

/***/ }),

/***/ "./src/service/order/index.ts":
/*!************************************!*\
  !*** ./src/service/order/index.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getRetailOrderList": function() { return /* binding */ getRetailOrderList; },
/* harmony export */   "getRetailOrderDetail": function() { return /* binding */ getRetailOrderDetail; },
/* harmony export */   "respushErp": function() { return /* binding */ respushErp; },
/* harmony export */   "getShopEnum": function() { return /* binding */ getShopEnum; },
/* harmony export */   "getWarehouseEnum": function() { return /* binding */ getWarehouseEnum; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _request_largeOrderRequest__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../request/largeOrderRequest */ "./src/service/request/largeOrderRequest.ts");



/** 订单列表 */

var _filehash = "P2Bg";
function getRetailOrderList(_x) {
  return _getRetailOrderList.apply(this, arguments);
}
/** 订单详情 */

function _getRetailOrderList() {
  _getRetailOrderList = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__.default)( /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().mark(function _callee(data) {
    return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", (0,_request_largeOrderRequest__WEBPACK_IMPORTED_MODULE_2__.default)({
              url: '/largeOrder/trade/list',
              method: 'POST',
              loading: true,
              data: data
            }));

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _getRetailOrderList.apply(this, arguments);
}

function getRetailOrderDetail(_x2) {
  return _getRetailOrderDetail.apply(this, arguments);
}
/** 推送erp */

function _getRetailOrderDetail() {
  _getRetailOrderDetail = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__.default)( /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().mark(function _callee2(data) {
    return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            return _context2.abrupt("return", (0,_request_largeOrderRequest__WEBPACK_IMPORTED_MODULE_2__.default)({
              url: '/largeOrder/trade/detail',
              method: 'POST',
              loading: true,
              data: data
            }));

          case 1:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _getRetailOrderDetail.apply(this, arguments);
}

function respushErp(_x3) {
  return _respushErp.apply(this, arguments);
}
/** 获取门店列表 */

function _respushErp() {
  _respushErp = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__.default)( /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().mark(function _callee3(data) {
    return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            return _context3.abrupt("return", (0,_request_largeOrderRequest__WEBPACK_IMPORTED_MODULE_2__.default)({
              url: '/largeOrder/trade/repush',
              method: 'POST',
              loading: true,
              data: data
            }));

          case 1:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
  return _respushErp.apply(this, arguments);
}

function getShopEnum(_x4) {
  return _getShopEnum.apply(this, arguments);
}
/** 获取仓库列表 */

function _getShopEnum() {
  _getShopEnum = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__.default)( /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().mark(function _callee4(data) {
    return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            return _context4.abrupt("return", (0,_request_largeOrderRequest__WEBPACK_IMPORTED_MODULE_2__.default)({
              url: '/largeOrder/shop/list',
              method: 'POST',
              loading: true,
              data: data
            }));

          case 1:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));
  return _getShopEnum.apply(this, arguments);
}

function getWarehouseEnum(_x5) {
  return _getWarehouseEnum.apply(this, arguments);
}

function _getWarehouseEnum() {
  _getWarehouseEnum = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__.default)( /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().mark(function _callee5(data) {
    return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            return _context5.abrupt("return", (0,_request_largeOrderRequest__WEBPACK_IMPORTED_MODULE_2__.default)({
              url: '/largeOrder/warehouse/list',
              method: 'POST',
              loading: true,
              data: data
            }));

          case 1:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5);
  }));
  return _getWarehouseEnum.apply(this, arguments);
}

/***/ }),

/***/ "./src/service/request/Loadding.ts":
/*!*****************************************!*\
  !*** ./src/service/request/Loadding.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Loading": function() { return /* binding */ Loading; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass.js");


var _filehash = "okqe";

/* eslint-disable no-console */
var Loading = /*#__PURE__*/function () {
  function Loading() {
    (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__.default)(this, Loading);

    this.isShow = false;
    this.timer = 0;
    this.stack = [];

    this.showHandler = function () {
      console.log('请设置showHandler');
    };

    this.hideHandler = function () {
      console.log('请设置hideHandler');
    };
  }

  (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__.default)(Loading, [{
    key: "show",
    value: function show() {
      var _this = this;

      if (!this.timer) {
        this.timer = setTimeout(function () {
          _this.showHandler();

          _this.isShow = true;
          clearTimeout(_this.timer);
        }, Loading.threshold);
      }

      this.stack.push(1);
    }
  }, {
    key: "hide",
    value: function hide() {
      var _this2 = this;

      return new Promise(function (resolve) {
        setTimeout(function () {
          _this2.stack.shift();

          if (_this2.stack.length === 0) {
            clearTimeout(_this2.timer);

            if (_this2.isShow === true) {
              _this2.hideHandler();

              _this2.isShow = false;
              _this2.timer = 0;
            }
          }

          resolve(true);
        }, Loading.delay);
      });
    }
  }]);

  return Loading;
}();
Loading.threshold = 0;
Loading.delay = 0;

/***/ }),

/***/ "./src/service/request/interceptors.ts":
/*!*********************************************!*\
  !*** ./src/service/request/interceptors.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "requestInterceptors": function() { return /* binding */ requestInterceptors; },
/* harmony export */   "responseInterceptors": function() { return /* binding */ responseInterceptors; },
/* harmony export */   "responseErrorHandler": function() { return /* binding */ responseErrorHandler; },
/* harmony export */   "responseLargeOrderInterceptors": function() { return /* binding */ responseLargeOrderInterceptors; }
/* harmony export */ });
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var antd_es_notification_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd/es/notification/style */ "./node_modules/antd/es/notification/style/index.js");
/* harmony import */ var antd_es_notification__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! antd/es/notification */ "./node_modules/antd/es/notification/index.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var antd_es_message_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd/es/message/style */ "./node_modules/antd/es/message/style/index.js");
/* harmony import */ var antd_es_message__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! antd/es/message */ "./node_modules/antd/es/message/index.js");
/* harmony import */ var umi__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! umi */ "./src/.umi/core/umiExports.ts");
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! querystring */ "./node_modules/querystring/index.js");
/* harmony import */ var _Loadding__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Loadding */ "./src/service/request/Loadding.ts");
/* harmony import */ var _utils_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/utils/storage */ "./src/utils/storage.ts");











var _filehash = "5reR";
_Loadding__WEBPACK_IMPORTED_MODULE_6__.Loading.delay = 300;
var loadingManger = new _Loadding__WEBPACK_IMPORTED_MODULE_6__.Loading();

loadingManger.showHandler = function () {
  console.log('显示loading');

  antd_es_message__WEBPACK_IMPORTED_MODULE_8__.default.loading('加载中', 0);
};

loadingManger.hideHandler = function () {
  console.log('关闭loading');

  antd_es_message__WEBPACK_IMPORTED_MODULE_8__.default.destroy();
};
/** 请求拦截器 */


function requestInterceptors(config) {
  //  请求头携带token
  // const token = getLocalStorage(TOKENKEY);
  if (config.loading) {
    loadingManger.show();
  }

  config.headers = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__.default)({}, config.headers);
  return config;
}
/** 响应拦截器 */

function responseInterceptors(_x) {
  return _responseInterceptors.apply(this, arguments);
}
/** 响应错误处理 */

function _responseInterceptors() {
  _responseInterceptors = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__.default)( /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().mark(function _callee(response) {
    var res;
    return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (!(response.config.responseType === 'arraybuffer')) {
              _context.next = 4;
              break;
            }

            _context.next = 3;
            return loadingManger.hide();

          case 3:
            return _context.abrupt("return", response.data);

          case 4:
            if (!response.config.loading) {
              _context.next = 7;
              break;
            }

            _context.next = 7;
            return loadingManger.hide();

          case 7:
            if (false) {}

            res = response.data;

            if (!(res.code === 200 || res.code === 0)) {
              _context.next = 11;
              break;
            }

            return _context.abrupt("return", res.data);

          case 11:
            if (!(res.code == null)) {
              _context.next = 14;
              break;
            }

            console.error("\u6CE8\u610F\uFF1A\u63A5\u53E3\"".concat(response.config.url, "\"\u672A\u6309\u524D\u7AEF\u6807\u51C6\u8FD4\u56DE\u6570\u636E\u7ED3\u6784\uFF0C\u8BF7\u63D0\u9192\u540E\u7AEF\u53CA\u65F6\u4FEE\u6539"));
            return _context.abrupt("return", response.data);

          case 14:
            if (!response.config.silence) {
              //   TODO TOAST 弹窗提示
              antd_es_notification__WEBPACK_IMPORTED_MODULE_9__.default.error({
                message: '系统繁忙',
                description: res.message
              });

              console.error(res.message || '接口出错');
            } //  自行处理响应数据


            return _context.abrupt("return", Promise.reject(new Error(res.message)));

          case 16:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _responseInterceptors.apply(this, arguments);
}

function responseErrorHandler(_x2) {
  return _responseErrorHandler.apply(this, arguments);
}
/** 响应拦截器 */

function _responseErrorHandler() {
  _responseErrorHandler = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__.default)( /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().mark(function _callee2(error) {
    var location, pathname, search, msg;
    return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            location = umi__WEBPACK_IMPORTED_MODULE_10__.history.location;
            pathname = location.pathname, search = location.search;
            console.log('出错信息:', error, error.config);
            _context2.t0 = error.response && error.response.status;
            _context2.next = _context2.t0 === 401 ? 6 : _context2.t0 === 404 ? 11 : _context2.t0 === 500 ? 13 : 15;
            break;

          case 6:
            //  无效令牌
            antd_es_notification__WEBPACK_IMPORTED_MODULE_9__.default.error({
              message: '登录失效，请重新登录'
            });

            (0,_utils_storage__WEBPACK_IMPORTED_MODULE_7__.removeLocalStorage)(_utils_storage__WEBPACK_IMPORTED_MODULE_7__.TOKENKEY);
            (0,_utils_storage__WEBPACK_IMPORTED_MODULE_7__.removeLocalStorage)(_utils_storage__WEBPACK_IMPORTED_MODULE_7__.USERINFOKEY);
            umi__WEBPACK_IMPORTED_MODULE_10__.history.replace({
              pathname: '/user/login',
              search: (0,querystring__WEBPACK_IMPORTED_MODULE_5__.stringify)({
                redirect: pathname + search
              })
            });
            return _context2.abrupt("break", 18);

          case 11:
            msg = '服务端接口不存在';
            return _context2.abrupt("break", 18);

          case 13:
            msg = '服务器出错';
            return _context2.abrupt("break", 18);

          case 15:
            msg = error.message;

            if (msg.includes('timeout')) {
              msg = '请求超时，请稍后重试!';
            } else {
              msg = '服务器出错';
            }

            return _context2.abrupt("break", 18);

          case 18:
            if (!error.config.loading) {
              _context2.next = 21;
              break;
            }

            _context2.next = 21;
            return loadingManger.hide();

          case 21:
            if (msg && !error.config.silence) {
              antd_es_notification__WEBPACK_IMPORTED_MODULE_9__.default.error({
                message: '系统繁忙',
                description: msg
              });

              console.error(msg || '接口出错');
            }

            return _context2.abrupt("return", Promise.reject(error));

          case 23:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _responseErrorHandler.apply(this, arguments);
}

function responseLargeOrderInterceptors(_x3) {
  return _responseLargeOrderInterceptors.apply(this, arguments);
}

function _responseLargeOrderInterceptors() {
  _responseLargeOrderInterceptors = (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__.default)( /*#__PURE__*/(0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().mark(function _callee3(response) {
    var res;
    return (0,_Users_hansc_Documents_project_business_end_order_node_modules_umijs_babel_preset_umi_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_0__.default)().wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            if (!(response.config.responseType === 'arraybuffer')) {
              _context3.next = 4;
              break;
            }

            _context3.next = 3;
            return loadingManger.hide();

          case 3:
            return _context3.abrupt("return", response.data);

          case 4:
            if (!response.config.loading) {
              _context3.next = 7;
              break;
            }

            _context3.next = 7;
            return loadingManger.hide();

          case 7:
            if (false) {}

            res = response.data;

            if (!(res.code === 0)) {
              _context3.next = 11;
              break;
            }

            return _context3.abrupt("return", res.data);

          case 11:
            if (!(res.code == null)) {
              _context3.next = 14;
              break;
            }

            console.error("\u6CE8\u610F\uFF1A\u63A5\u53E3\"".concat(response.config.url, "\"\u672A\u6309\u524D\u7AEF\u6807\u51C6\u8FD4\u56DE\u6570\u636E\u7ED3\u6784\uFF0C\u8BF7\u63D0\u9192\u540E\u7AEF\u53CA\u65F6\u4FEE\u6539"));
            return _context3.abrupt("return", response.data);

          case 14:
            if (!response.config.silence) {
              //   TODO TOAST 弹窗提示
              antd_es_notification__WEBPACK_IMPORTED_MODULE_9__.default.error({
                message: '系统繁忙',
                description: res.message
              });

              console.error(res.message || '接口出错');
            } //  自行处理响应数据


            return _context3.abrupt("return", Promise.reject(new Error(res.message)));

          case 16:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
  return _responseLargeOrderInterceptors.apply(this, arguments);
}

/***/ }),

/***/ "./src/service/request/largeOrderRequest.ts":
/*!**************************************************!*\
  !*** ./src/service/request/largeOrderRequest.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _interceptors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./interceptors */ "./src/service/request/interceptors.ts");


var _filehash = "iGNR";
var request = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
  baseURL: "https://test-largeorder.harmay.com",
  loading: false,
  silence: false
});
request.interceptors.request.use(_interceptors__WEBPACK_IMPORTED_MODULE_1__.requestInterceptors);
request.interceptors.response.use(_interceptors__WEBPACK_IMPORTED_MODULE_1__.responseInterceptors, _interceptors__WEBPACK_IMPORTED_MODULE_1__.responseErrorHandler);
/* harmony default export */ __webpack_exports__["default"] = (request);

/***/ }),

/***/ "./src/utils/storage.ts":
/*!******************************!*\
  !*** ./src/utils/storage.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TAGKEY": function() { return /* binding */ TAGKEY; },
/* harmony export */   "USERINFOKEY": function() { return /* binding */ USERINFOKEY; },
/* harmony export */   "TOKENKEY": function() { return /* binding */ TOKENKEY; },
/* harmony export */   "setLocalStorage": function() { return /* binding */ setLocalStorage; },
/* harmony export */   "getLocalStorage": function() { return /* binding */ getLocalStorage; },
/* harmony export */   "removeLocalStorage": function() { return /* binding */ removeLocalStorage; },
/* harmony export */   "setSessionStorage": function() { return /* binding */ setSessionStorage; },
/* harmony export */   "getSessionStorage": function() { return /* binding */ getSessionStorage; },
/* harmony export */   "removeSessionStorage": function() { return /* binding */ removeSessionStorage; }
/* harmony export */ });
var _filehash = "GFyu";
var TAGKEY = 'tag';
var USERINFOKEY = 'mdmUserInfo';
var TOKENKEY = 'mdmToken';
var setLocalStorage = function setLocalStorage(key, value) {
  if (typeof value === 'object') {
    localStorage.setItem(key, JSON.stringify(value));
  } else {
    localStorage.setItem(key, value);
  }
};
var getLocalStorage = function getLocalStorage(key) {
  var value = localStorage.getItem(key) || '';

  try {
    return JSON.parse(value);
  } catch (error) {
    return value;
  }
};
var removeLocalStorage = function removeLocalStorage(key) {
  localStorage.removeItem(key);
};
var setSessionStorage = function setSessionStorage(key, value) {
  if (typeof value === 'object') {
    sessionStorage.setItem(key, JSON.stringify(value));
  } else {
    sessionStorage.setItem(key, value);
  }
};
var getSessionStorage = function getSessionStorage(key) {
  var value = sessionStorage.getItem(key) || '';

  try {
    return JSON.parse(value);
  } catch (error) {
    return value;
  }
};
var removeSessionStorage = function removeSessionStorage(key) {
  sessionStorage.removeItem(key);
};

/***/ }),

/***/ "?34aa":
/*!******************************!*\
  !*** min-document (ignored) ***!
  \******************************/
/***/ (function() {

/* (ignored) */

/***/ }),

/***/ "?4f7e":
/*!********************************!*\
  !*** ./util.inspect (ignored) ***!
  \********************************/
/***/ (function() {

/* (ignored) */

/***/ })

}]);