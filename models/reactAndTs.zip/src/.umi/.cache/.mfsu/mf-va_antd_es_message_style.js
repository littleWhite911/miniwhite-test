import '/Users/hansc/Documents/project/business-end-order/node_modules/antd/es/message/style';
