import _ from 'react-activation';
export default _;
export * from 'react-activation';
