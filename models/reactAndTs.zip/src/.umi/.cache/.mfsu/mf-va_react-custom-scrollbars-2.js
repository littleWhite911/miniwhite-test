import _ from 'react-custom-scrollbars-2';
export default _;
export * from 'react-custom-scrollbars-2';
