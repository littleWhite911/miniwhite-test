import _ from 'lodash/noop';
export default _;
export * from 'lodash/noop';
