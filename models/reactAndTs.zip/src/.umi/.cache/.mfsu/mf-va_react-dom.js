import _ from '/Users/hansc/Documents/project/business-end-order/node_modules/react-dom';
export default _;
export * from '/Users/hansc/Documents/project/business-end-order/node_modules/react-dom';
