import _ from '/Users/hansc/Documents/project/business-end-order/node_modules/dumi-theme-default/es/builtins/Tree.js';
export default _;
