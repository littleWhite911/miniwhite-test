import _ from '/Users/hansc/Documents/project/business-end-order/node_modules/@umijs/preset-built-in/node_modules/regenerator-runtime/runtime.js';
export default _;
export * from '/Users/hansc/Documents/project/business-end-order/node_modules/@umijs/preset-built-in/node_modules/regenerator-runtime/runtime.js';
