import _ from 'querystring';
export default _;
export * from 'querystring';
