import _ from '@ant-design/icons';
export default _;
export * from '@ant-design/icons';
