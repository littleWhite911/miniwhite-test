(self["webpackChunkbusiness_end_order"] = self["webpackChunkbusiness_end_order"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_react-custom-scrollbars-2_js"],{

/***/ "./src/.umi/.cache/.mfsu/mf-va_react-custom-scrollbars-2.js":
/*!******************************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_react-custom-scrollbars-2.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Scrollbars": function() { return /* reexport safe */ react_custom_scrollbars_2__WEBPACK_IMPORTED_MODULE_0__.Scrollbars; },
/* harmony export */   "__esModule": function() { return /* reexport safe */ react_custom_scrollbars_2__WEBPACK_IMPORTED_MODULE_0__.__esModule; }
/* harmony export */ });
/* harmony import */ var react_custom_scrollbars_2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-custom-scrollbars-2 */ "./node_modules/react-custom-scrollbars-2/lib/index.js");

/* harmony default export */ __webpack_exports__["default"] = (react_custom_scrollbars_2__WEBPACK_IMPORTED_MODULE_0__.default);



/***/ })

}]);