// @ts-nocheck
import React from 'react';
import { dynamic } from 'dumi';
import rawCode1 from '!!dumi-raw-code-loader!/Users/hansc/Documents/project/business-end-order/src/components/DetailPageHeader/demo/index.tsx?dumi-raw-code';
import rawCode2 from '!!dumi-raw-code-loader!/Users/hansc/Documents/project/business-end-order/src/components/TagView/demo/index.tsx?dumi-raw-code';

export default {
  'detailpageheader-demo': {
    component: dynamic({
      loader: async () => (await import(/* webpackChunkName: "demos_redaeHegaPliateD" */'/Users/hansc/Documents/project/business-end-order/src/components/DetailPageHeader/demo/index.tsx')).default,
      loading: () => null,
    }),
    previewerProps: {"sources":{"_":{"tsx":rawCode1}},"dependencies":{},"componentName":"DetailPageHeader","identifier":"detailpageheader-demo"},
  },
  'tagview-demo': {
    component: dynamic({
      loader: async () => (await import(/* webpackChunkName: "demos_weiVgaT" */'/Users/hansc/Documents/project/business-end-order/src/components/TagView/demo/index.tsx')).default,
      loading: () => null,
    }),
    previewerProps: {"sources":{"_":{"tsx":rawCode2}},"dependencies":{},"componentName":"TagView","identifier":"tagview-demo"},
  },
};
