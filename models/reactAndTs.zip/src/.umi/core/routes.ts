// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from '/Users/hansc/Documents/project/business-end-order/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@ant-design/pro-layout/es/PageLoading';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: '.umi__plugin-layout__Layout' */'/Users/hansc/Documents/project/business-end-order/src/.umi/plugin-layout/Layout.tsx'), loading: LoadingComponent}),
    "routes": [
      {
        "path": "/~demos/:uuid",
        "layout": false,
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'../dumi/layout'), loading: LoadingComponent})],
        "component": ((props) => dynamic({
          loader: async () => {
            const React = await import('react');
            const { default: getDemoRenderArgs } = await import(/* webpackChunkName: 'dumi_demos' */ '/Users/hansc/Documents/project/business-end-order/node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs');
            const { default: Previewer } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi-theme-default/es/builtins/Previewer.js');
            const { usePrefersColor, context } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi/theme');

            return props => {
              
      const { demos } = React.useContext(context);
      const [renderArgs, setRenderArgs] = React.useState([]);

      // update render args when props changed
      React.useLayoutEffect(() => {
        setRenderArgs(getDemoRenderArgs(props, demos));
      }, [props.match.params.uuid, props.location.query.wrapper, props.location.query.capture]);

      // for listen prefers-color-schema media change in demo single route
      usePrefersColor();

      switch (renderArgs.length) {
        case 1:
          // render demo directly
          return renderArgs[0];

        case 2:
          // render demo with previewer
          return React.createElement(
            Previewer,
            renderArgs[0],
            renderArgs[1],
          );

        default:
          return `Demo ${props.match.params.uuid} not found :(`;
      }
    
            }
          },
          loading: () => null,
        }))()
      },
      {
        "path": "/_demos/:uuid",
        "redirect": "/~demos/:uuid"
      },
      {
        "__dumiRoot": true,
        "layout": false,
        "path": "/~docs",
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'../dumi/layout'), loading: LoadingComponent}), dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'/Users/hansc/Documents/project/business-end-order/node_modules/dumi-theme-default/es/layout.js'), loading: LoadingComponent})],
        "routes": [
          {
            "path": "/~docs",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'README.md' */'/Users/hansc/Documents/project/business-end-order/README.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "locale": "en-US",
              "order": null,
              "filePath": "README.md",
              "updatedTime": 1659064961000,
              "slugs": [
                {
                  "depth": 1,
                  "value": "Business End ORDER",
                  "heading": "business-end-order"
                }
              ],
              "title": "Business End ORDER"
            },
            "title": "Business End ORDER"
          },
          {
            "path": "/~docs/components",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'components__index.md' */'/Users/hansc/Documents/project/business-end-order/src/components/index.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "filePath": "src/components/index.md",
              "updatedTime": 1659064961000,
              "title": "业务组件",
              "sidemenu": false,
              "slugs": [],
              "group": {
                "path": "/~docs/components",
                "title": "Components"
              }
            },
            "title": "业务组件 - business-end-order"
          },
          {
            "path": "/~docs/components/detail-page-header",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'components__DetailPageHeader__index.md' */'/Users/hansc/Documents/project/business-end-order/src/components/DetailPageHeader/index.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "filePath": "src/components/DetailPageHeader/index.md",
              "updatedTime": 1659064961000,
              "componentName": "DetailPageHeader",
              "slugs": [
                {
                  "depth": 1,
                  "value": "DetailPageHeader",
                  "heading": "detailpageheader"
                },
                {
                  "depth": 2,
                  "value": "详情页页头 v0.1",
                  "heading": "详情页页头-v01"
                },
                {
                  "depth": 2,
                  "value": "API",
                  "heading": "api"
                }
              ],
              "title": "DetailPageHeader",
              "hasPreviewer": true,
              "group": {
                "path": "/~docs/components",
                "title": "Components"
              }
            },
            "title": "DetailPageHeader - business-end-order"
          },
          {
            "path": "/~docs/components/tag-view",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'components__TagView__index.md' */'/Users/hansc/Documents/project/business-end-order/src/components/TagView/index.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "filePath": "src/components/TagView/index.md",
              "updatedTime": 1659064961000,
              "componentName": "TagView",
              "slugs": [
                {
                  "depth": 1,
                  "value": "TagView",
                  "heading": "tagview"
                },
                {
                  "depth": 2,
                  "value": "tagView 多标签tab v0.1",
                  "heading": "tagview-多标签tab-v01"
                },
                {
                  "depth": 2,
                  "value": "API",
                  "heading": "api"
                }
              ],
              "title": "TagView",
              "hasPreviewer": true,
              "group": {
                "path": "/~docs/components",
                "title": "Components"
              }
            },
            "title": "TagView - business-end-order"
          }
        ],
        "title": "business-end-order",
        "component": (props) => props.children
      },
      {
        "path": "/user",
        "layout": false,
        "routes": [
          {
            "path": "/user",
            "routes": [
              {
                "name": "登录",
                "path": "/user/login",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__Login' */'/Users/hansc/Documents/project/business-end-order/src/pages/user/Login'), loading: LoadingComponent}),
                "hideInTab": true,
                "exact": true
              }
            ]
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'/Users/hansc/Documents/project/business-end-order/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/welcome",
        "name": "欢迎",
        "icon": "smile",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'/Users/hansc/Documents/project/business-end-order/src/pages/Welcome'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/order",
        "name": "订单中心",
        "routes": [
          {
            "path": "/order/retailOrderList",
            "name": "零售订单",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__order__retailOrderList' */'/Users/hansc/Documents/project/business-end-order/src/pages/order/retailOrderList'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/order/retailOrderDetail",
            "name": "零售订单详情",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__order__retailOrderDetail' */'/Users/hansc/Documents/project/business-end-order/src/pages/order/retailOrderDetail'), loading: LoadingComponent}),
            "hideInMenu": true,
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'/Users/hansc/Documents/project/business-end-order/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/index.html",
        "redirect": "/welcome",
        "exact": true
      },
      {
        "path": "/",
        "redirect": "/welcome",
        "exact": true
      },
      {
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'/Users/hansc/Documents/project/business-end-order/src/pages/404'), loading: LoadingComponent}),
        "exact": true
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
