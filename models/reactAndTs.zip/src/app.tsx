import type { Settings as LayoutSettings } from '@ant-design/pro-layout';
import { PageLoading } from '@ant-design/pro-layout';
import { KeepAlive, RunTimeLayoutConfig, Link, history } from 'umi';
import { BookOutlined } from '@ant-design/icons';
import RightContent from '@/components/RightContent';
import defaultSettings from '../config/defaultSettings';
import TagView from './components/TagView';
import eventEmitter from './components/TagView/utils/eventEmitter';

const isDev = process.env.NODE_ENV === 'development';
// const loginPath = '/user/login';

/** 获取用户信息比较慢的时候会展示一个 loading */
export const initialStateConfig = {
  loading: <PageLoading />,
};

/**
 * @see  https://umijs.org/zh-CN/plugins/plugin-initial-state
 * */
export async function getInitialState(): Promise<{
  settings?: Partial<LayoutSettings>;
  currentUser?: API.CurrentUser;
  loading?: boolean;
  fetchUserInfo?: () => Promise<API.CurrentUser | undefined>;
}> {
  // const fetchUserInfo = async () => {
  //   try {
  //     const msg = await queryCurrentUser();
  //     return msg.data;
  //   } catch (error) {
  //     history.push(loginPath);
  //   }
  //   return undefined;
  // };
  // // 如果是登录页面，不执行
  // if (history.location.pathname !== loginPath) {
  //   const currentUser = await fetchUserInfo();
  //   return {
  //     fetchUserInfo,
  //     currentUser,
  //     settings: defaultSettings,
  //   };
  // }
  return {
    // fetchUserInfo,
    currentUser: {},
    settings: defaultSettings,
  };
}

// ProLayout 支持的api https://procomponents.ant.design/components/layout
export const layout: RunTimeLayoutConfig = ({ initialState, setInitialState }) => ({
  // rightContentRender: ({ route, collapsed, siderWidth }) => (
  //   <TagView routes={route.routes} collapsed={collapsed || false} siderWidth={siderWidth || 208} />
  // ),
  rightContentRender: () => <RightContent />,
  onPageChange: () => {
    // if (getLocalStorage('token')) {
    // eslint-disable-next-line no-restricted-globals
    // eventEmitter.emit('routerChange', location);
    //   return;
    // }
    // const { location } = history;
    // 如果没有登录，重定向到 login
    // if (!initialState?.currentUser && location.pathname !== loginPath) {
    //   history.push(loginPath);
    // }
  },
  headerRender: (window as any).__POWERED_BY_QIANKUN__ ? false : undefined,
  links: isDev
    ? [
      // <Link to="/umi/plugin/openapi" target="_blank">
      //   <LinkOutlined />
      //   <span>OpenAPI 文档</span>
      // </Link>,
      <Link to="/~docs">
        <BookOutlined />
        <span>业务组件文档</span>
      </Link>,
    ]
    : [],
  // 自定义 403 页面
  // unAccessible: <div>unAccessible</div>,
  // 增加一个 loading 的状态
  childrenRender: (children, props) => (
    children
    // <KeepAlive
    //   saveScrollPosition="screen" // 自动保存共享屏幕容器的滚动位置
    //   id={history.location.search || history.location.pathname} // 根据参数去缓存，如果参数不同就缓存多份，如果参数相同就使用同一个缓存。这样解决了传参改变时，页面不刷新的问题
    //   // true卸载时缓存，false卸载时不缓存， // 根据路由的前进和后退状态去判断页面是否需要缓存，前进时缓存，后退时不缓存（卸载）。 when中的代码是在页面离开（卸载）时触发的。
    //   when={() => history.action !== 'POP'}>
    //   {children}
    // </KeepAlive>
  ),
  ...initialState?.settings,
});
