import { Effect, Reducer } from 'umi';
import { getShopEnum, getWarehouseEnum } from '@/service/order';

export interface OrderModelState {
  shopEnum: Record<string, string>;
  warehouseEnum: Record<string, string>;
}

export interface OrderModelType {
  namespace: string;
  state: OrderModelState;
  effects: {
    getShopEnum: Effect;
    getWarehouseEnum: Effect;
  };
  reducers: {
    saveShopEnum: Reducer<OrderModelState>;
    saveWarehouseEnum: Reducer<OrderModelState>;
  };
}

const OrderModel: OrderModelType = {
  namespace: 'order',
  state: {
    shopEnum: {},
    warehouseEnum: {},
  },

  effects: {
    *getShopEnum(payload, { call, put }) {
      const res = yield call(getShopEnum, {
        pageNo: 1,
        pageSize: 99999
      });
      const enumObj = {};
      res.records?.forEach((v: RetailOrder.resShopItem) => {
        enumObj[v.erpStoreCode!] = v.fliposStoreName;
      });
      yield put({
        type: 'saveShopEnum',
        payload: {
          shopEnum: enumObj
        },
      });
    },
    *getWarehouseEnum(payload, { call, put }) {
      const res = yield call(getWarehouseEnum, {
        pageNo: 1,
        pageSize: 99999
      });
      const enumObj = {};
      res.records?.forEach((v: RetailOrder.resShopItem) => {
        enumObj[v.erpWarehouseNo!] = v.erpWarehouseName;
      });
      yield put({
        type: 'saveWarehouseEnum',
        payload: {
          warehouseEnum: enumObj
        },
      });
    }
  },
  reducers: {
    saveShopEnum(state, action) {
      return {
        ...state,
        ...action.payload,
      };
    },
    saveWarehouseEnum(state, action) {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
};

export default OrderModel;
